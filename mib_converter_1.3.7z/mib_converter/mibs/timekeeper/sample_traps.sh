sudo snmptrap -v 2c -c public 127.0.0.1:5000 1 \
1.3.6.1.4.1.42733.0.4.5 \
1.3.6.1.4.1.42733.0.4.5.1 s "Theres a big problem somewhere" 