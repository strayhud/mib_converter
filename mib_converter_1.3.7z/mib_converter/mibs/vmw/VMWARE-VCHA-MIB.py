_VmwVchaNodeRoleType_type = {
  "1": "active",
  "2": "passive",
  "3": "witness",
  "4": "unknown"
}
_VmwVchaClusterModeType_type = {
  "1": "enabled",
  "2": "disabled",
  "3": "maintenance"
}
_VmwVchaClusterStateType_type = {
  "1": "healthy",
  "2": "degraded",
  "3": "isolated"
}
_VmwVchaDbReplicationStateType_type = {
  "1": "noReplication",
  "3": "sync",
  "4": "async"
}
_VmwVchaFileReplicationProviderType_type = {
  "1": "serviceConfig",
  "2": "serviceState"
}

_vmwVchaNodeJoined_vbinds = {
  "vmwVchaTargetNodeRole" : _VmwVchaNodeRoleType_type
}
_vmwVchaNodeLeft_vbinds = {
  "vmwVchaTargetNodeRole" : _VmwVchaNodeRoleType_type
}
_vmwVchaNodeIsolated_vbinds = {
  "vmwVchaTargetNodeRole" : _VmwVchaNodeRoleType_type
}
_vmwVchaClusterStateChanged_vbinds = {
  "vmwVchaClusterState" : _VmwVchaClusterStateType_type
}
_vmwVchaClusterModeChanged_vbinds = {
  "vmwVchaClusterMode" : _VmwVchaClusterModeType_type
}
_vmwVchaDbReplicationStateChanged_vbinds = {
  "vmwVchaDbReplicationState" : _VmwVchaDbReplicationStateType_type
}
_vmwVchaFileReplicationStateChanged_vbinds = {
  "vmwVchaFileReplicationProvider" : _VmwVchaFileReplicationProviderType_type
}

traps = {
  "vmwVchaNodeJoined" : _vmwVchaNodeJoined_vbinds,
  "vmwVchaNodeLeft" : _vmwVchaNodeLeft_vbinds,
  "vmwVchaNodeIsolated" : _vmwVchaNodeIsolated_vbinds,
  "vmwVchaClusterStateChanged" : _vmwVchaClusterStateChanged_vbinds,
  "vmwVchaClusterModeChanged" : _vmwVchaClusterModeChanged_vbinds,
  "vmwVchaDbReplicationStateChanged" : _vmwVchaDbReplicationStateChanged_vbinds,
  "vmwVchaFileReplicationStateChanged" : _vmwVchaFileReplicationStateChanged_vbinds
}