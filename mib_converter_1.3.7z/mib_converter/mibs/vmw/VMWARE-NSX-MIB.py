_VmwNsxTDataCenterFeatureIdType_type = {
  "1": "managerHealth",
  "2": "edgeHealth",
  "3": "certificates",
  "4": "passwordManagement",
  "5": "licenses",
  "6": "intelligenceHealth",
  "7": "infrastructureCommunication",
  "9": "intelligenceCommunication",
  "10": "cniHealth",
  "11": "ncpHealth",
  "12": "nodeAgentsHealth",
  "13": "endpointProtection",
  "15": "vpn",
  "16": "alarmManagement",
  "17": "loadBalancer",
  "18": "transportNodeHealth",
  "19": "infrastructureService",
  "20": "dhcp",
  "21": "highAvailability",
  "22": "capacity",
  "24": "auditLogHealth",
  "28": "routing",
  "30": "dns",
  "31": "distributedFirewall",
  "32": "federation",
  "33": "distributedIdsIps",
  "35": "communication",
  "36": "identityFirewall"
}
_VmwNsxTDataCenterSeverityType_type = {
  "0": "emergency",
  "1": "alert",
  "2": "critical",
  "3": "error",
  "4": "warning",
  "5": "notice",
  "6": "informational",
  "7": "debug"
}
_VmwNsxTDataCenterNodeTypeType_type = {
  "0": "manager",
  "1": "edge",
  "2": "esx",
  "3": "kvm",
  "4": "publiccloudgateway",
  "5": "intelligence",
  "6": "autonomousedge",
  "7": "globalmanager"
}

_vmwNsxTAlarmManagementAlarmServiceOverloaded_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAlarmManagementAlarmServiceOverloadedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAlarmManagementHeavyVolumeOfAlarms_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAlarmManagementHeavyVolumeOfAlarmsClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAuditLogHealthAuditLogFileUpdateError_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAuditLogHealthAuditLogFileUpdateErrorClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAuditLogHealthRemoteLoggingServerError_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTAuditLogHealthRemoteLoggingServerErrorClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMaximumCapacity_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMaximumCapacityClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMaximumCapacityThreshold_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMaximumCapacityThresholdClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMinimumCapacityThreshold_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCapacityMinimumCapacityThresholdClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateExpirationApproaching_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateExpirationApproachingClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateExpired_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateExpiredClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateIsAboutToExpire_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCertificatesCertificateIsAboutToExpireClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCniHealthHyperbusManagerConnectionDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCniHealthHyperbusManagerConnectionDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToManagerNodeDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToManagerNodeDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToManagerNodeDownTooLong_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToManagerNodeDownTooLongClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToTransportNodeDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToTransportNodeDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToTransportNodeDownLong_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationControlChannelToTransportNodeDownLongClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagementChannelToTransportNodeDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagementChannelToTransportNodeDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagementChannelToTransportNodeDownLg_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagementChannelToTransportNodeDownLgClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerClusterLatencyHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerClusterLatencyHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerControlChannelDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerControlChannelDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerFQDNLookupFailure_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerFQDNLookupFailureClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerFQDNReverseLookupFailure_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTCommunicationManagerFQDNReverseLookupFailureClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDHCPPoolLeaseAllocationFailed_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDHCPPoolLeaseAllocationFailedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDHCPPoolOverloaded_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDHCPPoolOverloadedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedFirewallDFWCPUUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedFirewallDFWCPUUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedFirewallDFWMemoryUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedFirewallDFWMemoryUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSMaxEventsReached_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSMaxEventsReachedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDNSForwarderDisabled_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDNSForwarderDisabledClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDNSForwarderDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTDNSForwarderDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthDatapathThreadDeadlocked_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthDatapathThreadDeadlockedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeCPUUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeCPUUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeCPUUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeCPUUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathConfigurationFailure_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathConfigurationFailureClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCPUHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCPUHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCPUVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCPUVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCryptodrvDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathCryptodrvDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathMempoolHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDatapathMempoolHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDiskUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDiskUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDiskUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeDiskUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeMemoryUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeMemoryUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeMemoryUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeMemoryUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICLinkStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICLinkStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICOutOfReceiveBuffer_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICOutOfReceiveBufferClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICOutOfTransmitBuffer_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthEdgeNICOutOfTransmitBufferClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthStorageError_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEdgeHealthStorageErrorClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEndpointProtectionEAMStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEndpointProtectionEAMStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEndpointProtectionPartnerChannelDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTEndpointProtectionPartnerChannelDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationGMToGMSplitBrain_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationGMToGMSplitBrainClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationLmToLmSynchronizationError_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationLmToLmSynchronizationErrorClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationLmToLmSynchronizationWarning_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationLmToLmSynchronizationWarningClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationRtepBGPDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationRtepBGPDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationRtepConnectivityLost_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTFederationRtepConnectivityLostClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTHighAvailabilityTier0GatewayFailover_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTHighAvailabilityTier0GatewayFailoverClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTHighAvailabilityTier1GatewayFailover_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTHighAvailabilityTier1GatewayFailoverClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIdentityFirewallConnectivityToLDAPServerLost_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIdentityFirewallConnectivityToLDAPServerLostClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIdentityFirewallErrorInDeltaSync_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIdentityFirewallErrorInDeltaSyncClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureCommunicationEdgeTunnelsDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureCommunicationEdgeTunnelsDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceEdgeServiceStatusChanged_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceEdgeServiceStatusChangedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceEdgeServiceStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceEdgeServiceStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceServiceStatusUnknown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTInfrastructureServiceServiceStatusUnknownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnected_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnectedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthCPUUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthCPUUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthCPUUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthCPUUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDataDiskPartitionUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDataDiskPartitionUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDiskUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDiskUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDiskUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthDiskUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthMemoryUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthMemoryUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthMemoryUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthMemoryUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthNodeStatusDegraded_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthNodeStatusDegradedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthStorageLatencyHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTIntelligenceHealthStorageLatencyHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLicensesLicenseExpired_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLicensesLicenseExpiredClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLicensesLicenseIsAboutToExpire_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLicensesLicenseIsAboutToExpireClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerLBCPUVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerLBCPUVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerLBStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerLBStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerPoolStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerPoolStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerVirtualServerStatusDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTLoadBalancerVirtualServerStatusDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthDuplicateIPAddress_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthDuplicateIPAddressClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerConfigDiskUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerConfigDiskUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerConfigDiskUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerConfigDiskUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerCPUUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerCPUUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerCPUUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerCPUUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerDiskUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerDiskUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerDiskUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerDiskUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerMemoryUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerMemoryUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerMemoryUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthManagerMemoryUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthOperationsDbDiskUsageHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthOperationsDbDiskUsageHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthOperationsDbDiskUsageVeryHigh_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthOperationsDbDiskUsageVeryHighClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthStorageError_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTManagerHealthStorageErrorClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTNCPHealthNCPPluginDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTNCPHealthNCPPluginDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTNodeAgentsHealthNodeAgentsDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTNodeAgentsHealthNodeAgentsDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordExpirationApproaching_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordExpirationApproachingClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordExpired_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordExpiredClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordIsAboutToExpire_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTPasswordManagementPasswordIsAboutToExpireClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingBFDDownOnExternalInterface_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingBFDDownOnExternalInterfaceClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingBGPDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingBGPDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingOSPFNeighborWentDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingOSPFNeighborWentDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingRoutingDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingRoutingDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingStaticRoutingRemoved_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTRoutingStaticRoutingRemovedClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTTransportNodeHealthLAGMemberDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTTransportNodeHealthLAGMemberDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTTransportNodeHealthNVDSUplinkDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTTransportNodeHealthNVDSUplinkDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecPolicyBasedSessionDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecPolicyBasedSessionDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecPolicyBasedTunnelDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecPolicyBasedTunnelDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecRouteBasedSessionDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecRouteBasedSessionDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecRouteBasedTunnelDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNIPsecRouteBasedTunnelDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNL2VpnSessionDown_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}
_vmwNsxTVPNL2VpnSessionDownClear_vbinds = {
  "vmwNsxTDataCenterFeatureName" : _VmwNsxTDataCenterFeatureIdType_type,
  "vmwNsxTDataCenterEventSeverity" : _VmwNsxTDataCenterSeverityType_type,
  "vmwNsxTDataCenterNodeType" : _VmwNsxTDataCenterNodeTypeType_type
}

traps = {
  "vmwNsxTAlarmManagementAlarmServiceOverloaded" : _vmwNsxTAlarmManagementAlarmServiceOverloaded_vbinds,
  "vmwNsxTAlarmManagementAlarmServiceOverloadedClear" : _vmwNsxTAlarmManagementAlarmServiceOverloadedClear_vbinds,
  "vmwNsxTAlarmManagementHeavyVolumeOfAlarms" : _vmwNsxTAlarmManagementHeavyVolumeOfAlarms_vbinds,
  "vmwNsxTAlarmManagementHeavyVolumeOfAlarmsClear" : _vmwNsxTAlarmManagementHeavyVolumeOfAlarmsClear_vbinds,
  "vmwNsxTAuditLogHealthAuditLogFileUpdateError" : _vmwNsxTAuditLogHealthAuditLogFileUpdateError_vbinds,
  "vmwNsxTAuditLogHealthAuditLogFileUpdateErrorClear" : _vmwNsxTAuditLogHealthAuditLogFileUpdateErrorClear_vbinds,
  "vmwNsxTAuditLogHealthRemoteLoggingServerError" : _vmwNsxTAuditLogHealthRemoteLoggingServerError_vbinds,
  "vmwNsxTAuditLogHealthRemoteLoggingServerErrorClear" : _vmwNsxTAuditLogHealthRemoteLoggingServerErrorClear_vbinds,
  "vmwNsxTCapacityMaximumCapacity" : _vmwNsxTCapacityMaximumCapacity_vbinds,
  "vmwNsxTCapacityMaximumCapacityClear" : _vmwNsxTCapacityMaximumCapacityClear_vbinds,
  "vmwNsxTCapacityMaximumCapacityThreshold" : _vmwNsxTCapacityMaximumCapacityThreshold_vbinds,
  "vmwNsxTCapacityMaximumCapacityThresholdClear" : _vmwNsxTCapacityMaximumCapacityThresholdClear_vbinds,
  "vmwNsxTCapacityMinimumCapacityThreshold" : _vmwNsxTCapacityMinimumCapacityThreshold_vbinds,
  "vmwNsxTCapacityMinimumCapacityThresholdClear" : _vmwNsxTCapacityMinimumCapacityThresholdClear_vbinds,
  "vmwNsxTCertificatesCertificateExpirationApproaching" : _vmwNsxTCertificatesCertificateExpirationApproaching_vbinds,
  "vmwNsxTCertificatesCertificateExpirationApproachingClear" : _vmwNsxTCertificatesCertificateExpirationApproachingClear_vbinds,
  "vmwNsxTCertificatesCertificateExpired" : _vmwNsxTCertificatesCertificateExpired_vbinds,
  "vmwNsxTCertificatesCertificateExpiredClear" : _vmwNsxTCertificatesCertificateExpiredClear_vbinds,
  "vmwNsxTCertificatesCertificateIsAboutToExpire" : _vmwNsxTCertificatesCertificateIsAboutToExpire_vbinds,
  "vmwNsxTCertificatesCertificateIsAboutToExpireClear" : _vmwNsxTCertificatesCertificateIsAboutToExpireClear_vbinds,
  "vmwNsxTCniHealthHyperbusManagerConnectionDown" : _vmwNsxTCniHealthHyperbusManagerConnectionDown_vbinds,
  "vmwNsxTCniHealthHyperbusManagerConnectionDownClear" : _vmwNsxTCniHealthHyperbusManagerConnectionDownClear_vbinds,
  "vmwNsxTCommunicationControlChannelToManagerNodeDown" : _vmwNsxTCommunicationControlChannelToManagerNodeDown_vbinds,
  "vmwNsxTCommunicationControlChannelToManagerNodeDownClear" : _vmwNsxTCommunicationControlChannelToManagerNodeDownClear_vbinds,
  "vmwNsxTCommunicationControlChannelToManagerNodeDownTooLong" : _vmwNsxTCommunicationControlChannelToManagerNodeDownTooLong_vbinds,
  "vmwNsxTCommunicationControlChannelToManagerNodeDownTooLongClear" : _vmwNsxTCommunicationControlChannelToManagerNodeDownTooLongClear_vbinds,
  "vmwNsxTCommunicationControlChannelToTransportNodeDown" : _vmwNsxTCommunicationControlChannelToTransportNodeDown_vbinds,
  "vmwNsxTCommunicationControlChannelToTransportNodeDownClear" : _vmwNsxTCommunicationControlChannelToTransportNodeDownClear_vbinds,
  "vmwNsxTCommunicationControlChannelToTransportNodeDownLong" : _vmwNsxTCommunicationControlChannelToTransportNodeDownLong_vbinds,
  "vmwNsxTCommunicationControlChannelToTransportNodeDownLongClear" : _vmwNsxTCommunicationControlChannelToTransportNodeDownLongClear_vbinds,
  "vmwNsxTCommunicationManagementChannelToTransportNodeDown" : _vmwNsxTCommunicationManagementChannelToTransportNodeDown_vbinds,
  "vmwNsxTCommunicationManagementChannelToTransportNodeDownClear" : _vmwNsxTCommunicationManagementChannelToTransportNodeDownClear_vbinds,
  "vmwNsxTCommunicationManagementChannelToTransportNodeDownLg" : _vmwNsxTCommunicationManagementChannelToTransportNodeDownLg_vbinds,
  "vmwNsxTCommunicationManagementChannelToTransportNodeDownLgClear" : _vmwNsxTCommunicationManagementChannelToTransportNodeDownLgClear_vbinds,
  "vmwNsxTCommunicationManagerClusterLatencyHigh" : _vmwNsxTCommunicationManagerClusterLatencyHigh_vbinds,
  "vmwNsxTCommunicationManagerClusterLatencyHighClear" : _vmwNsxTCommunicationManagerClusterLatencyHighClear_vbinds,
  "vmwNsxTCommunicationManagerControlChannelDown" : _vmwNsxTCommunicationManagerControlChannelDown_vbinds,
  "vmwNsxTCommunicationManagerControlChannelDownClear" : _vmwNsxTCommunicationManagerControlChannelDownClear_vbinds,
  "vmwNsxTCommunicationManagerFQDNLookupFailure" : _vmwNsxTCommunicationManagerFQDNLookupFailure_vbinds,
  "vmwNsxTCommunicationManagerFQDNLookupFailureClear" : _vmwNsxTCommunicationManagerFQDNLookupFailureClear_vbinds,
  "vmwNsxTCommunicationManagerFQDNReverseLookupFailure" : _vmwNsxTCommunicationManagerFQDNReverseLookupFailure_vbinds,
  "vmwNsxTCommunicationManagerFQDNReverseLookupFailureClear" : _vmwNsxTCommunicationManagerFQDNReverseLookupFailureClear_vbinds,
  "vmwNsxTDHCPPoolLeaseAllocationFailed" : _vmwNsxTDHCPPoolLeaseAllocationFailed_vbinds,
  "vmwNsxTDHCPPoolLeaseAllocationFailedClear" : _vmwNsxTDHCPPoolLeaseAllocationFailedClear_vbinds,
  "vmwNsxTDHCPPoolOverloaded" : _vmwNsxTDHCPPoolOverloaded_vbinds,
  "vmwNsxTDHCPPoolOverloadedClear" : _vmwNsxTDHCPPoolOverloadedClear_vbinds,
  "vmwNsxTDistributedFirewallDFWCPUUsageVeryHigh" : _vmwNsxTDistributedFirewallDFWCPUUsageVeryHigh_vbinds,
  "vmwNsxTDistributedFirewallDFWCPUUsageVeryHighClear" : _vmwNsxTDistributedFirewallDFWCPUUsageVeryHighClear_vbinds,
  "vmwNsxTDistributedFirewallDFWMemoryUsageVeryHigh" : _vmwNsxTDistributedFirewallDFWMemoryUsageVeryHigh_vbinds,
  "vmwNsxTDistributedFirewallDFWMemoryUsageVeryHighClear" : _vmwNsxTDistributedFirewallDFWMemoryUsageVeryHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSMaxEventsReached" : _vmwNsxTDistributedIDSIPSMaxEventsReached_vbinds,
  "vmwNsxTDistributedIDSIPSMaxEventsReachedClear" : _vmwNsxTDistributedIDSIPSMaxEventsReachedClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageMediumHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineCPUUsageVeryHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineDown" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineDown_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineDownClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineDownClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageMediumHighClear_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHigh" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHigh_vbinds,
  "vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHighClear" : _vmwNsxTDistributedIDSIPSNSXIDPSEngineMemoryUsageVeryHighClear_vbinds,
  "vmwNsxTDNSForwarderDisabled" : _vmwNsxTDNSForwarderDisabled_vbinds,
  "vmwNsxTDNSForwarderDisabledClear" : _vmwNsxTDNSForwarderDisabledClear_vbinds,
  "vmwNsxTDNSForwarderDown" : _vmwNsxTDNSForwarderDown_vbinds,
  "vmwNsxTDNSForwarderDownClear" : _vmwNsxTDNSForwarderDownClear_vbinds,
  "vmwNsxTEdgeHealthDatapathThreadDeadlocked" : _vmwNsxTEdgeHealthDatapathThreadDeadlocked_vbinds,
  "vmwNsxTEdgeHealthDatapathThreadDeadlockedClear" : _vmwNsxTEdgeHealthDatapathThreadDeadlockedClear_vbinds,
  "vmwNsxTEdgeHealthEdgeCPUUsageHigh" : _vmwNsxTEdgeHealthEdgeCPUUsageHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeCPUUsageHighClear" : _vmwNsxTEdgeHealthEdgeCPUUsageHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeCPUUsageVeryHigh" : _vmwNsxTEdgeHealthEdgeCPUUsageVeryHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeCPUUsageVeryHighClear" : _vmwNsxTEdgeHealthEdgeCPUUsageVeryHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathConfigurationFailure" : _vmwNsxTEdgeHealthEdgeDatapathConfigurationFailure_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathConfigurationFailureClear" : _vmwNsxTEdgeHealthEdgeDatapathConfigurationFailureClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCPUHigh" : _vmwNsxTEdgeHealthEdgeDatapathCPUHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCPUHighClear" : _vmwNsxTEdgeHealthEdgeDatapathCPUHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCPUVeryHigh" : _vmwNsxTEdgeHealthEdgeDatapathCPUVeryHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCPUVeryHighClear" : _vmwNsxTEdgeHealthEdgeDatapathCPUVeryHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCryptodrvDown" : _vmwNsxTEdgeHealthEdgeDatapathCryptodrvDown_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathCryptodrvDownClear" : _vmwNsxTEdgeHealthEdgeDatapathCryptodrvDownClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathMempoolHigh" : _vmwNsxTEdgeHealthEdgeDatapathMempoolHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeDatapathMempoolHighClear" : _vmwNsxTEdgeHealthEdgeDatapathMempoolHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDiskUsageHigh" : _vmwNsxTEdgeHealthEdgeDiskUsageHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeDiskUsageHighClear" : _vmwNsxTEdgeHealthEdgeDiskUsageHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeDiskUsageVeryHigh" : _vmwNsxTEdgeHealthEdgeDiskUsageVeryHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeDiskUsageVeryHighClear" : _vmwNsxTEdgeHealthEdgeDiskUsageVeryHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHigh" : _vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHighClear" : _vmwNsxTEdgeHealthEdgeGlobalARPTableUsageHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeMemoryUsageHigh" : _vmwNsxTEdgeHealthEdgeMemoryUsageHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeMemoryUsageHighClear" : _vmwNsxTEdgeHealthEdgeMemoryUsageHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeMemoryUsageVeryHigh" : _vmwNsxTEdgeHealthEdgeMemoryUsageVeryHigh_vbinds,
  "vmwNsxTEdgeHealthEdgeMemoryUsageVeryHighClear" : _vmwNsxTEdgeHealthEdgeMemoryUsageVeryHighClear_vbinds,
  "vmwNsxTEdgeHealthEdgeNICLinkStatusDown" : _vmwNsxTEdgeHealthEdgeNICLinkStatusDown_vbinds,
  "vmwNsxTEdgeHealthEdgeNICLinkStatusDownClear" : _vmwNsxTEdgeHealthEdgeNICLinkStatusDownClear_vbinds,
  "vmwNsxTEdgeHealthEdgeNICOutOfReceiveBuffer" : _vmwNsxTEdgeHealthEdgeNICOutOfReceiveBuffer_vbinds,
  "vmwNsxTEdgeHealthEdgeNICOutOfReceiveBufferClear" : _vmwNsxTEdgeHealthEdgeNICOutOfReceiveBufferClear_vbinds,
  "vmwNsxTEdgeHealthEdgeNICOutOfTransmitBuffer" : _vmwNsxTEdgeHealthEdgeNICOutOfTransmitBuffer_vbinds,
  "vmwNsxTEdgeHealthEdgeNICOutOfTransmitBufferClear" : _vmwNsxTEdgeHealthEdgeNICOutOfTransmitBufferClear_vbinds,
  "vmwNsxTEdgeHealthStorageError" : _vmwNsxTEdgeHealthStorageError_vbinds,
  "vmwNsxTEdgeHealthStorageErrorClear" : _vmwNsxTEdgeHealthStorageErrorClear_vbinds,
  "vmwNsxTEndpointProtectionEAMStatusDown" : _vmwNsxTEndpointProtectionEAMStatusDown_vbinds,
  "vmwNsxTEndpointProtectionEAMStatusDownClear" : _vmwNsxTEndpointProtectionEAMStatusDownClear_vbinds,
  "vmwNsxTEndpointProtectionPartnerChannelDown" : _vmwNsxTEndpointProtectionPartnerChannelDown_vbinds,
  "vmwNsxTEndpointProtectionPartnerChannelDownClear" : _vmwNsxTEndpointProtectionPartnerChannelDownClear_vbinds,
  "vmwNsxTFederationGMToGMSplitBrain" : _vmwNsxTFederationGMToGMSplitBrain_vbinds,
  "vmwNsxTFederationGMToGMSplitBrainClear" : _vmwNsxTFederationGMToGMSplitBrainClear_vbinds,
  "vmwNsxTFederationLmToLmSynchronizationError" : _vmwNsxTFederationLmToLmSynchronizationError_vbinds,
  "vmwNsxTFederationLmToLmSynchronizationErrorClear" : _vmwNsxTFederationLmToLmSynchronizationErrorClear_vbinds,
  "vmwNsxTFederationLmToLmSynchronizationWarning" : _vmwNsxTFederationLmToLmSynchronizationWarning_vbinds,
  "vmwNsxTFederationLmToLmSynchronizationWarningClear" : _vmwNsxTFederationLmToLmSynchronizationWarningClear_vbinds,
  "vmwNsxTFederationRtepBGPDown" : _vmwNsxTFederationRtepBGPDown_vbinds,
  "vmwNsxTFederationRtepBGPDownClear" : _vmwNsxTFederationRtepBGPDownClear_vbinds,
  "vmwNsxTFederationRtepConnectivityLost" : _vmwNsxTFederationRtepConnectivityLost_vbinds,
  "vmwNsxTFederationRtepConnectivityLostClear" : _vmwNsxTFederationRtepConnectivityLostClear_vbinds,
  "vmwNsxTHighAvailabilityTier0GatewayFailover" : _vmwNsxTHighAvailabilityTier0GatewayFailover_vbinds,
  "vmwNsxTHighAvailabilityTier0GatewayFailoverClear" : _vmwNsxTHighAvailabilityTier0GatewayFailoverClear_vbinds,
  "vmwNsxTHighAvailabilityTier1GatewayFailover" : _vmwNsxTHighAvailabilityTier1GatewayFailover_vbinds,
  "vmwNsxTHighAvailabilityTier1GatewayFailoverClear" : _vmwNsxTHighAvailabilityTier1GatewayFailoverClear_vbinds,
  "vmwNsxTIdentityFirewallConnectivityToLDAPServerLost" : _vmwNsxTIdentityFirewallConnectivityToLDAPServerLost_vbinds,
  "vmwNsxTIdentityFirewallConnectivityToLDAPServerLostClear" : _vmwNsxTIdentityFirewallConnectivityToLDAPServerLostClear_vbinds,
  "vmwNsxTIdentityFirewallErrorInDeltaSync" : _vmwNsxTIdentityFirewallErrorInDeltaSync_vbinds,
  "vmwNsxTIdentityFirewallErrorInDeltaSyncClear" : _vmwNsxTIdentityFirewallErrorInDeltaSyncClear_vbinds,
  "vmwNsxTInfrastructureCommunicationEdgeTunnelsDown" : _vmwNsxTInfrastructureCommunicationEdgeTunnelsDown_vbinds,
  "vmwNsxTInfrastructureCommunicationEdgeTunnelsDownClear" : _vmwNsxTInfrastructureCommunicationEdgeTunnelsDownClear_vbinds,
  "vmwNsxTInfrastructureServiceEdgeServiceStatusChanged" : _vmwNsxTInfrastructureServiceEdgeServiceStatusChanged_vbinds,
  "vmwNsxTInfrastructureServiceEdgeServiceStatusChangedClear" : _vmwNsxTInfrastructureServiceEdgeServiceStatusChangedClear_vbinds,
  "vmwNsxTInfrastructureServiceEdgeServiceStatusDown" : _vmwNsxTInfrastructureServiceEdgeServiceStatusDown_vbinds,
  "vmwNsxTInfrastructureServiceEdgeServiceStatusDownClear" : _vmwNsxTInfrastructureServiceEdgeServiceStatusDownClear_vbinds,
  "vmwNsxTInfrastructureServiceServiceStatusUnknown" : _vmwNsxTInfrastructureServiceServiceStatusUnknown_vbinds,
  "vmwNsxTInfrastructureServiceServiceStatusUnknownClear" : _vmwNsxTInfrastructureServiceServiceStatusUnknownClear_vbinds,
  "vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnected" : _vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnected_vbinds,
  "vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnectedClear" : _vmwNsxTIntelligenceCommunicationTNFlowExporterDisconnectedClear_vbinds,
  "vmwNsxTIntelligenceHealthCPUUsageHigh" : _vmwNsxTIntelligenceHealthCPUUsageHigh_vbinds,
  "vmwNsxTIntelligenceHealthCPUUsageHighClear" : _vmwNsxTIntelligenceHealthCPUUsageHighClear_vbinds,
  "vmwNsxTIntelligenceHealthCPUUsageVeryHigh" : _vmwNsxTIntelligenceHealthCPUUsageVeryHigh_vbinds,
  "vmwNsxTIntelligenceHealthCPUUsageVeryHighClear" : _vmwNsxTIntelligenceHealthCPUUsageVeryHighClear_vbinds,
  "vmwNsxTIntelligenceHealthDataDiskPartitionUsageHigh" : _vmwNsxTIntelligenceHealthDataDiskPartitionUsageHigh_vbinds,
  "vmwNsxTIntelligenceHealthDataDiskPartitionUsageHighClear" : _vmwNsxTIntelligenceHealthDataDiskPartitionUsageHighClear_vbinds,
  "vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHigh" : _vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHigh_vbinds,
  "vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHighClear" : _vmwNsxTIntelligenceHealthDataDiskPartitionUsageVeryHighClear_vbinds,
  "vmwNsxTIntelligenceHealthDiskUsageHigh" : _vmwNsxTIntelligenceHealthDiskUsageHigh_vbinds,
  "vmwNsxTIntelligenceHealthDiskUsageHighClear" : _vmwNsxTIntelligenceHealthDiskUsageHighClear_vbinds,
  "vmwNsxTIntelligenceHealthDiskUsageVeryHigh" : _vmwNsxTIntelligenceHealthDiskUsageVeryHigh_vbinds,
  "vmwNsxTIntelligenceHealthDiskUsageVeryHighClear" : _vmwNsxTIntelligenceHealthDiskUsageVeryHighClear_vbinds,
  "vmwNsxTIntelligenceHealthMemoryUsageHigh" : _vmwNsxTIntelligenceHealthMemoryUsageHigh_vbinds,
  "vmwNsxTIntelligenceHealthMemoryUsageHighClear" : _vmwNsxTIntelligenceHealthMemoryUsageHighClear_vbinds,
  "vmwNsxTIntelligenceHealthMemoryUsageVeryHigh" : _vmwNsxTIntelligenceHealthMemoryUsageVeryHigh_vbinds,
  "vmwNsxTIntelligenceHealthMemoryUsageVeryHighClear" : _vmwNsxTIntelligenceHealthMemoryUsageVeryHighClear_vbinds,
  "vmwNsxTIntelligenceHealthNodeStatusDegraded" : _vmwNsxTIntelligenceHealthNodeStatusDegraded_vbinds,
  "vmwNsxTIntelligenceHealthNodeStatusDegradedClear" : _vmwNsxTIntelligenceHealthNodeStatusDegradedClear_vbinds,
  "vmwNsxTIntelligenceHealthStorageLatencyHigh" : _vmwNsxTIntelligenceHealthStorageLatencyHigh_vbinds,
  "vmwNsxTIntelligenceHealthStorageLatencyHighClear" : _vmwNsxTIntelligenceHealthStorageLatencyHighClear_vbinds,
  "vmwNsxTLicensesLicenseExpired" : _vmwNsxTLicensesLicenseExpired_vbinds,
  "vmwNsxTLicensesLicenseExpiredClear" : _vmwNsxTLicensesLicenseExpiredClear_vbinds,
  "vmwNsxTLicensesLicenseIsAboutToExpire" : _vmwNsxTLicensesLicenseIsAboutToExpire_vbinds,
  "vmwNsxTLicensesLicenseIsAboutToExpireClear" : _vmwNsxTLicensesLicenseIsAboutToExpireClear_vbinds,
  "vmwNsxTLoadBalancerLBCPUVeryHigh" : _vmwNsxTLoadBalancerLBCPUVeryHigh_vbinds,
  "vmwNsxTLoadBalancerLBCPUVeryHighClear" : _vmwNsxTLoadBalancerLBCPUVeryHighClear_vbinds,
  "vmwNsxTLoadBalancerLBStatusDown" : _vmwNsxTLoadBalancerLBStatusDown_vbinds,
  "vmwNsxTLoadBalancerLBStatusDownClear" : _vmwNsxTLoadBalancerLBStatusDownClear_vbinds,
  "vmwNsxTLoadBalancerPoolStatusDown" : _vmwNsxTLoadBalancerPoolStatusDown_vbinds,
  "vmwNsxTLoadBalancerPoolStatusDownClear" : _vmwNsxTLoadBalancerPoolStatusDownClear_vbinds,
  "vmwNsxTLoadBalancerVirtualServerStatusDown" : _vmwNsxTLoadBalancerVirtualServerStatusDown_vbinds,
  "vmwNsxTLoadBalancerVirtualServerStatusDownClear" : _vmwNsxTLoadBalancerVirtualServerStatusDownClear_vbinds,
  "vmwNsxTManagerHealthDuplicateIPAddress" : _vmwNsxTManagerHealthDuplicateIPAddress_vbinds,
  "vmwNsxTManagerHealthDuplicateIPAddressClear" : _vmwNsxTManagerHealthDuplicateIPAddressClear_vbinds,
  "vmwNsxTManagerHealthManagerConfigDiskUsageHigh" : _vmwNsxTManagerHealthManagerConfigDiskUsageHigh_vbinds,
  "vmwNsxTManagerHealthManagerConfigDiskUsageHighClear" : _vmwNsxTManagerHealthManagerConfigDiskUsageHighClear_vbinds,
  "vmwNsxTManagerHealthManagerConfigDiskUsageVeryHigh" : _vmwNsxTManagerHealthManagerConfigDiskUsageVeryHigh_vbinds,
  "vmwNsxTManagerHealthManagerConfigDiskUsageVeryHighClear" : _vmwNsxTManagerHealthManagerConfigDiskUsageVeryHighClear_vbinds,
  "vmwNsxTManagerHealthManagerCPUUsageHigh" : _vmwNsxTManagerHealthManagerCPUUsageHigh_vbinds,
  "vmwNsxTManagerHealthManagerCPUUsageHighClear" : _vmwNsxTManagerHealthManagerCPUUsageHighClear_vbinds,
  "vmwNsxTManagerHealthManagerCPUUsageVeryHigh" : _vmwNsxTManagerHealthManagerCPUUsageVeryHigh_vbinds,
  "vmwNsxTManagerHealthManagerCPUUsageVeryHighClear" : _vmwNsxTManagerHealthManagerCPUUsageVeryHighClear_vbinds,
  "vmwNsxTManagerHealthManagerDiskUsageHigh" : _vmwNsxTManagerHealthManagerDiskUsageHigh_vbinds,
  "vmwNsxTManagerHealthManagerDiskUsageHighClear" : _vmwNsxTManagerHealthManagerDiskUsageHighClear_vbinds,
  "vmwNsxTManagerHealthManagerDiskUsageVeryHigh" : _vmwNsxTManagerHealthManagerDiskUsageVeryHigh_vbinds,
  "vmwNsxTManagerHealthManagerDiskUsageVeryHighClear" : _vmwNsxTManagerHealthManagerDiskUsageVeryHighClear_vbinds,
  "vmwNsxTManagerHealthManagerMemoryUsageHigh" : _vmwNsxTManagerHealthManagerMemoryUsageHigh_vbinds,
  "vmwNsxTManagerHealthManagerMemoryUsageHighClear" : _vmwNsxTManagerHealthManagerMemoryUsageHighClear_vbinds,
  "vmwNsxTManagerHealthManagerMemoryUsageVeryHigh" : _vmwNsxTManagerHealthManagerMemoryUsageVeryHigh_vbinds,
  "vmwNsxTManagerHealthManagerMemoryUsageVeryHighClear" : _vmwNsxTManagerHealthManagerMemoryUsageVeryHighClear_vbinds,
  "vmwNsxTManagerHealthOperationsDbDiskUsageHigh" : _vmwNsxTManagerHealthOperationsDbDiskUsageHigh_vbinds,
  "vmwNsxTManagerHealthOperationsDbDiskUsageHighClear" : _vmwNsxTManagerHealthOperationsDbDiskUsageHighClear_vbinds,
  "vmwNsxTManagerHealthOperationsDbDiskUsageVeryHigh" : _vmwNsxTManagerHealthOperationsDbDiskUsageVeryHigh_vbinds,
  "vmwNsxTManagerHealthOperationsDbDiskUsageVeryHighClear" : _vmwNsxTManagerHealthOperationsDbDiskUsageVeryHighClear_vbinds,
  "vmwNsxTManagerHealthStorageError" : _vmwNsxTManagerHealthStorageError_vbinds,
  "vmwNsxTManagerHealthStorageErrorClear" : _vmwNsxTManagerHealthStorageErrorClear_vbinds,
  "vmwNsxTNCPHealthNCPPluginDown" : _vmwNsxTNCPHealthNCPPluginDown_vbinds,
  "vmwNsxTNCPHealthNCPPluginDownClear" : _vmwNsxTNCPHealthNCPPluginDownClear_vbinds,
  "vmwNsxTNodeAgentsHealthNodeAgentsDown" : _vmwNsxTNodeAgentsHealthNodeAgentsDown_vbinds,
  "vmwNsxTNodeAgentsHealthNodeAgentsDownClear" : _vmwNsxTNodeAgentsHealthNodeAgentsDownClear_vbinds,
  "vmwNsxTPasswordManagementPasswordExpirationApproaching" : _vmwNsxTPasswordManagementPasswordExpirationApproaching_vbinds,
  "vmwNsxTPasswordManagementPasswordExpirationApproachingClear" : _vmwNsxTPasswordManagementPasswordExpirationApproachingClear_vbinds,
  "vmwNsxTPasswordManagementPasswordExpired" : _vmwNsxTPasswordManagementPasswordExpired_vbinds,
  "vmwNsxTPasswordManagementPasswordExpiredClear" : _vmwNsxTPasswordManagementPasswordExpiredClear_vbinds,
  "vmwNsxTPasswordManagementPasswordIsAboutToExpire" : _vmwNsxTPasswordManagementPasswordIsAboutToExpire_vbinds,
  "vmwNsxTPasswordManagementPasswordIsAboutToExpireClear" : _vmwNsxTPasswordManagementPasswordIsAboutToExpireClear_vbinds,
  "vmwNsxTRoutingBFDDownOnExternalInterface" : _vmwNsxTRoutingBFDDownOnExternalInterface_vbinds,
  "vmwNsxTRoutingBFDDownOnExternalInterfaceClear" : _vmwNsxTRoutingBFDDownOnExternalInterfaceClear_vbinds,
  "vmwNsxTRoutingBGPDown" : _vmwNsxTRoutingBGPDown_vbinds,
  "vmwNsxTRoutingBGPDownClear" : _vmwNsxTRoutingBGPDownClear_vbinds,
  "vmwNsxTRoutingOSPFNeighborWentDown" : _vmwNsxTRoutingOSPFNeighborWentDown_vbinds,
  "vmwNsxTRoutingOSPFNeighborWentDownClear" : _vmwNsxTRoutingOSPFNeighborWentDownClear_vbinds,
  "vmwNsxTRoutingRoutingDown" : _vmwNsxTRoutingRoutingDown_vbinds,
  "vmwNsxTRoutingRoutingDownClear" : _vmwNsxTRoutingRoutingDownClear_vbinds,
  "vmwNsxTRoutingStaticRoutingRemoved" : _vmwNsxTRoutingStaticRoutingRemoved_vbinds,
  "vmwNsxTRoutingStaticRoutingRemovedClear" : _vmwNsxTRoutingStaticRoutingRemovedClear_vbinds,
  "vmwNsxTTransportNodeHealthLAGMemberDown" : _vmwNsxTTransportNodeHealthLAGMemberDown_vbinds,
  "vmwNsxTTransportNodeHealthLAGMemberDownClear" : _vmwNsxTTransportNodeHealthLAGMemberDownClear_vbinds,
  "vmwNsxTTransportNodeHealthNVDSUplinkDown" : _vmwNsxTTransportNodeHealthNVDSUplinkDown_vbinds,
  "vmwNsxTTransportNodeHealthNVDSUplinkDownClear" : _vmwNsxTTransportNodeHealthNVDSUplinkDownClear_vbinds,
  "vmwNsxTVPNIPsecPolicyBasedSessionDown" : _vmwNsxTVPNIPsecPolicyBasedSessionDown_vbinds,
  "vmwNsxTVPNIPsecPolicyBasedSessionDownClear" : _vmwNsxTVPNIPsecPolicyBasedSessionDownClear_vbinds,
  "vmwNsxTVPNIPsecPolicyBasedTunnelDown" : _vmwNsxTVPNIPsecPolicyBasedTunnelDown_vbinds,
  "vmwNsxTVPNIPsecPolicyBasedTunnelDownClear" : _vmwNsxTVPNIPsecPolicyBasedTunnelDownClear_vbinds,
  "vmwNsxTVPNIPsecRouteBasedSessionDown" : _vmwNsxTVPNIPsecRouteBasedSessionDown_vbinds,
  "vmwNsxTVPNIPsecRouteBasedSessionDownClear" : _vmwNsxTVPNIPsecRouteBasedSessionDownClear_vbinds,
  "vmwNsxTVPNIPsecRouteBasedTunnelDown" : _vmwNsxTVPNIPsecRouteBasedTunnelDown_vbinds,
  "vmwNsxTVPNIPsecRouteBasedTunnelDownClear" : _vmwNsxTVPNIPsecRouteBasedTunnelDownClear_vbinds,
  "vmwNsxTVPNL2VpnSessionDown" : _vmwNsxTVPNL2VpnSessionDown_vbinds,
  "vmwNsxTVPNL2VpnSessionDownClear" : _vmwNsxTVPNL2VpnSessionDownClear_vbinds
}