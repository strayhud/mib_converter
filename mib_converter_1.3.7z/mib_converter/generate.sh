#!/usr/bin/env bash

node ./bin/ecgen.js $@
#node /usr/local/bin/ecgen.js $@
