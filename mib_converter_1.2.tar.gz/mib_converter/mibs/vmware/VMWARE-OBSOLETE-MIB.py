_VmwSubsystemTypes_type = {
  "1": "unknown",
  "2": "chassis",
  "3": "powerSupply",
  "4": "fan",
  "5": "cpu",
  "6": "memory",
  "7": "battery",
  "8": "temperatureSensor",
  "9": "raidController",
  "10": "voltage"
}
_VmwCIMAlertTypes_type = {
  "1": "other",
  "2": "communications",
  "3": "qos",
  "4": "processingError",
  "5": "deviceAlert",
  "6": "environmentalAlert",
  "7": "modelChange",
  "8": "securityAlert"
}
_VmwCIMAlertFormat_type = {
  "0": "unknown",
  "1": "other",
  "2": "cimObjectPath"
}
_VmwSubsystemStatus_type = {
  "1": "unknown",
  "2": "normal",
  "3": "marginal",
  "4": "critical",
  "5": "failed"
}
_VmwCIMSeverity_type = {
  "0": "unknown",
  "1": "other",
  "2": "information",
  "3": "warning",
  "4": "minor",
  "5": "major",
  "6": "critical",
  "7": "fatal"
}

_vmwEnvHardwareEvent_vbinds = {
  "vmwSubsystemType" : _VmwSubsystemTypes_type,
  "vmwHardwareStatus" : _VmwSubsystemStatus_type
}
_vmwESXEnvHardwareEvent_vbinds = {
  "vmwSubsystemType" : _VmwSubsystemTypes_type,
  "vmwHardwareStatus" : _VmwSubsystemStatus_type
}
_vmwESXEnvHardwareAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvBatteryAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvChassisAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvThermalAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvDiskAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvPowerAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvProcessorAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvMemoryAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}
_vmwESXEnvBIOSAlert_vbinds = {
  "vmwEnvPerceivedSeverity" : _VmwCIMSeverity_type,
  "vmwEnvAlertType" : _VmwCIMAlertTypes_type,
  "vmwEnvAlertingFormat" : _VmwCIMAlertFormat_type
}

traps = {
  "vmwEnvHardwareEvent" : _vmwEnvHardwareEvent_vbinds,
  "vmwESXEnvHardwareEvent" : _vmwESXEnvHardwareEvent_vbinds,
  "vmwESXEnvHardwareAlert" : _vmwESXEnvHardwareAlert_vbinds,
  "vmwESXEnvBatteryAlert" : _vmwESXEnvBatteryAlert_vbinds,
  "vmwESXEnvChassisAlert" : _vmwESXEnvChassisAlert_vbinds,
  "vmwESXEnvThermalAlert" : _vmwESXEnvThermalAlert_vbinds,
  "vmwESXEnvDiskAlert" : _vmwESXEnvDiskAlert_vbinds,
  "vmwESXEnvPowerAlert" : _vmwESXEnvPowerAlert_vbinds,
  "vmwESXEnvProcessorAlert" : _vmwESXEnvProcessorAlert_vbinds,
  "vmwESXEnvMemoryAlert" : _vmwESXEnvMemoryAlert_vbinds,
  "vmwESXEnvBIOSAlert" : _vmwESXEnvBIOSAlert_vbinds
}