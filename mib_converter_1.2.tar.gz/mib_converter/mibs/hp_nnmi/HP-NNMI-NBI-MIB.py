_NnmiNature_type = {
  "1": "rootcause",
  "2": "secondaryrootcause",
  "3": "symptom",
  "4": "serviceimpact",
  "5": "streamcorrelation",
  "6": "none",
  "7": "info",
  "8": "dedupStreamCorrelation",
  "9": "rateStreamCorrelation"
}
_NnmiSeverity_type = {
  "1": "normal",
  "2": "warning",
  "3": "minor",
  "4": "major",
  "5": "critical"
}
_NnmiPriority_type = {
  "1": "top",
  "2": "high",
  "3": "medium",
  "4": "low",
  "5": "none"
}
_NnmiLifecycleState_type = {
  "1": "registered",
  "2": "inprogress",
  "3": "completed",
  "4": "closed",
  "5": "dampened"
}

_nnmiMgmtEvAddressNotResponding_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvAggregatorDegraded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvAggregatorDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvAggregatorLinkDegraded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvAggregatorLinkDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvBufferOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvConnectionDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvConnectionPartiallyUnresponsive_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCpuOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCustomPollCritical_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCustomPollMajor_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCustomPollMinor_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCustomPollWarning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvDuplicateCorrelation_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvFanOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvImportantNodeOrConnectionDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvImportantNodeUnmanageable_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvInterfaceDisabled_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvInterfaceDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvInterfacePerformanceCritical_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvInterfacePerformanceWarning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvIslandGroupDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvLicenseExpired_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvLicenseMismatch_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvLicenseNodeCountExceeded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvMemoryOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvModifiedConnectionDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNnmClusterFailover_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNnmClusterLostStandby_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNnmClusterStartup_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNnmClusterTransfer_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNodeDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNodeOrConnectionDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNonSNMPNodeUnresponsive_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvPowerSupplyOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRateCorrelation_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgDegraded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgFailover_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgMultiplePrimary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgMultipleSecondary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgNoPrimary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgNoSecondary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvRrgSecondaryChanged_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvSnmpTrapLimitCritical_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvSnmpTrapLimitMajor_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvSnmpTrapLimitWarning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvTemperatureOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvTrapStorm_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvVoltageOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvMessageQueueIncidentRateExceeded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvMessageQueueSizeExceeded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvPipelineQueueSizeExceeded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCardDown_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCardRemoved_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCardDisabled_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCrgNoPrimary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCrgMultiplePrimary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCrgNoSecondary_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCrgFailover_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvLicensePointCountNearCapacity_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvLicenseCapacityCountExceeded_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCardInserted_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvNnmHealthOverallStatus_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCardUndeterminedState_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvDiskOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvBackplaneOutOfRangeOrMalfunctioning_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvIpSubnetContainsIpWithNewMac_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvSNMPAgentNotResponding_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvCpuAbnormal_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvMemoryAbnormal_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvBufferAbnormal_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvBackplaneAbnormal_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvDiskAbnormal_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiMgmtEvGenericIncident_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiEvClosed_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}
_nnmiEvLifecycleStateChanged_vbinds = {
  "nnmiIncidentLifecycleStatePreviousValue" : _NnmiLifecycleState_type,
  "nnmiIncidentLifecycleStateCurrentValue" : _NnmiLifecycleState_type
}
_nnmiSyslog_vbinds = {
  "nnmiIncidentNature" : _NnmiNature_type,
  "nnmiIncidentSeverity" : _NnmiSeverity_type,
  "nnmiIncidentPriority" : _NnmiPriority_type,
  "nnmiIncidentLifecycleState" : _NnmiLifecycleState_type
}

traps = {
  "nnmiMgmtEvAddressNotResponding" : _nnmiMgmtEvAddressNotResponding_vbinds,
  "nnmiMgmtEvAggregatorDegraded" : _nnmiMgmtEvAggregatorDegraded_vbinds,
  "nnmiMgmtEvAggregatorDown" : _nnmiMgmtEvAggregatorDown_vbinds,
  "nnmiMgmtEvAggregatorLinkDegraded" : _nnmiMgmtEvAggregatorLinkDegraded_vbinds,
  "nnmiMgmtEvAggregatorLinkDown" : _nnmiMgmtEvAggregatorLinkDown_vbinds,
  "nnmiMgmtEvBufferOutOfRangeOrMalfunctioning" : _nnmiMgmtEvBufferOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvConnectionDown" : _nnmiMgmtEvConnectionDown_vbinds,
  "nnmiMgmtEvConnectionPartiallyUnresponsive" : _nnmiMgmtEvConnectionPartiallyUnresponsive_vbinds,
  "nnmiMgmtEvCpuOutOfRangeOrMalfunctioning" : _nnmiMgmtEvCpuOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvCustomPollCritical" : _nnmiMgmtEvCustomPollCritical_vbinds,
  "nnmiMgmtEvCustomPollMajor" : _nnmiMgmtEvCustomPollMajor_vbinds,
  "nnmiMgmtEvCustomPollMinor" : _nnmiMgmtEvCustomPollMinor_vbinds,
  "nnmiMgmtEvCustomPollWarning" : _nnmiMgmtEvCustomPollWarning_vbinds,
  "nnmiMgmtEvDuplicateCorrelation" : _nnmiMgmtEvDuplicateCorrelation_vbinds,
  "nnmiMgmtEvFanOutOfRangeOrMalfunctioning" : _nnmiMgmtEvFanOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvImportantNodeOrConnectionDown" : _nnmiMgmtEvImportantNodeOrConnectionDown_vbinds,
  "nnmiMgmtEvImportantNodeUnmanageable" : _nnmiMgmtEvImportantNodeUnmanageable_vbinds,
  "nnmiMgmtEvInterfaceDisabled" : _nnmiMgmtEvInterfaceDisabled_vbinds,
  "nnmiMgmtEvInterfaceDown" : _nnmiMgmtEvInterfaceDown_vbinds,
  "nnmiMgmtEvInterfacePerformanceCritical" : _nnmiMgmtEvInterfacePerformanceCritical_vbinds,
  "nnmiMgmtEvInterfacePerformanceWarning" : _nnmiMgmtEvInterfacePerformanceWarning_vbinds,
  "nnmiMgmtEvIslandGroupDown" : _nnmiMgmtEvIslandGroupDown_vbinds,
  "nnmiMgmtEvLicenseExpired" : _nnmiMgmtEvLicenseExpired_vbinds,
  "nnmiMgmtEvLicenseMismatch" : _nnmiMgmtEvLicenseMismatch_vbinds,
  "nnmiMgmtEvLicenseNodeCountExceeded" : _nnmiMgmtEvLicenseNodeCountExceeded_vbinds,
  "nnmiMgmtEvMemoryOutOfRangeOrMalfunctioning" : _nnmiMgmtEvMemoryOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvModifiedConnectionDown" : _nnmiMgmtEvModifiedConnectionDown_vbinds,
  "nnmiMgmtEvNnmClusterFailover" : _nnmiMgmtEvNnmClusterFailover_vbinds,
  "nnmiMgmtEvNnmClusterLostStandby" : _nnmiMgmtEvNnmClusterLostStandby_vbinds,
  "nnmiMgmtEvNnmClusterStartup" : _nnmiMgmtEvNnmClusterStartup_vbinds,
  "nnmiMgmtEvNnmClusterTransfer" : _nnmiMgmtEvNnmClusterTransfer_vbinds,
  "nnmiMgmtEvNodeDown" : _nnmiMgmtEvNodeDown_vbinds,
  "nnmiMgmtEvNodeOrConnectionDown" : _nnmiMgmtEvNodeOrConnectionDown_vbinds,
  "nnmiMgmtEvNonSNMPNodeUnresponsive" : _nnmiMgmtEvNonSNMPNodeUnresponsive_vbinds,
  "nnmiMgmtEvPowerSupplyOutOfRangeOrMalfunctioning" : _nnmiMgmtEvPowerSupplyOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvRateCorrelation" : _nnmiMgmtEvRateCorrelation_vbinds,
  "nnmiMgmtEvRrgDegraded" : _nnmiMgmtEvRrgDegraded_vbinds,
  "nnmiMgmtEvRrgFailover" : _nnmiMgmtEvRrgFailover_vbinds,
  "nnmiMgmtEvRrgMultiplePrimary" : _nnmiMgmtEvRrgMultiplePrimary_vbinds,
  "nnmiMgmtEvRrgMultipleSecondary" : _nnmiMgmtEvRrgMultipleSecondary_vbinds,
  "nnmiMgmtEvRrgNoPrimary" : _nnmiMgmtEvRrgNoPrimary_vbinds,
  "nnmiMgmtEvRrgNoSecondary" : _nnmiMgmtEvRrgNoSecondary_vbinds,
  "nnmiMgmtEvRrgSecondaryChanged" : _nnmiMgmtEvRrgSecondaryChanged_vbinds,
  "nnmiMgmtEvSnmpTrapLimitCritical" : _nnmiMgmtEvSnmpTrapLimitCritical_vbinds,
  "nnmiMgmtEvSnmpTrapLimitMajor" : _nnmiMgmtEvSnmpTrapLimitMajor_vbinds,
  "nnmiMgmtEvSnmpTrapLimitWarning" : _nnmiMgmtEvSnmpTrapLimitWarning_vbinds,
  "nnmiMgmtEvTemperatureOutOfRangeOrMalfunctioning" : _nnmiMgmtEvTemperatureOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvTrapStorm" : _nnmiMgmtEvTrapStorm_vbinds,
  "nnmiMgmtEvVoltageOutOfRangeOrMalfunctioning" : _nnmiMgmtEvVoltageOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvMessageQueueIncidentRateExceeded" : _nnmiMgmtEvMessageQueueIncidentRateExceeded_vbinds,
  "nnmiMgmtEvMessageQueueSizeExceeded" : _nnmiMgmtEvMessageQueueSizeExceeded_vbinds,
  "nnmiMgmtEvPipelineQueueSizeExceeded" : _nnmiMgmtEvPipelineQueueSizeExceeded_vbinds,
  "nnmiMgmtEvCardDown" : _nnmiMgmtEvCardDown_vbinds,
  "nnmiMgmtEvCardRemoved" : _nnmiMgmtEvCardRemoved_vbinds,
  "nnmiMgmtEvCardDisabled" : _nnmiMgmtEvCardDisabled_vbinds,
  "nnmiMgmtEvCrgNoPrimary" : _nnmiMgmtEvCrgNoPrimary_vbinds,
  "nnmiMgmtEvCrgMultiplePrimary" : _nnmiMgmtEvCrgMultiplePrimary_vbinds,
  "nnmiMgmtEvCrgNoSecondary" : _nnmiMgmtEvCrgNoSecondary_vbinds,
  "nnmiMgmtEvCrgFailover" : _nnmiMgmtEvCrgFailover_vbinds,
  "nnmiMgmtEvLicensePointCountNearCapacity" : _nnmiMgmtEvLicensePointCountNearCapacity_vbinds,
  "nnmiMgmtEvLicenseCapacityCountExceeded" : _nnmiMgmtEvLicenseCapacityCountExceeded_vbinds,
  "nnmiMgmtEvCardInserted" : _nnmiMgmtEvCardInserted_vbinds,
  "nnmiMgmtEvNnmHealthOverallStatus" : _nnmiMgmtEvNnmHealthOverallStatus_vbinds,
  "nnmiMgmtEvCardUndeterminedState" : _nnmiMgmtEvCardUndeterminedState_vbinds,
  "nnmiMgmtEvDiskOutOfRangeOrMalfunctioning" : _nnmiMgmtEvDiskOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvBackplaneOutOfRangeOrMalfunctioning" : _nnmiMgmtEvBackplaneOutOfRangeOrMalfunctioning_vbinds,
  "nnmiMgmtEvIpSubnetContainsIpWithNewMac" : _nnmiMgmtEvIpSubnetContainsIpWithNewMac_vbinds,
  "nnmiMgmtEvSNMPAgentNotResponding" : _nnmiMgmtEvSNMPAgentNotResponding_vbinds,
  "nnmiMgmtEvCpuAbnormal" : _nnmiMgmtEvCpuAbnormal_vbinds,
  "nnmiMgmtEvMemoryAbnormal" : _nnmiMgmtEvMemoryAbnormal_vbinds,
  "nnmiMgmtEvBufferAbnormal" : _nnmiMgmtEvBufferAbnormal_vbinds,
  "nnmiMgmtEvBackplaneAbnormal" : _nnmiMgmtEvBackplaneAbnormal_vbinds,
  "nnmiMgmtEvDiskAbnormal" : _nnmiMgmtEvDiskAbnormal_vbinds,
  "nnmiMgmtEvGenericIncident" : _nnmiMgmtEvGenericIncident_vbinds,
  "nnmiEvClosed" : _nnmiEvClosed_vbinds,
  "nnmiEvLifecycleStateChanged" : _nnmiEvLifecycleStateChanged_vbinds,
  "nnmiSyslog" : _nnmiSyslog_vbinds
}