This directory contains some raw event configs for the vmware mibs.
They were generated with a mib_converter utility and will mostly likey
need updating. They are considered raw because they should be reviewed 
and updated to make alerts in BP more useful.  Specifically in the area 
of setting primary and secondary keys as well as status values. 

These were converted using the following default values for primary/secondary:

    "primary": "snmp_source_ip",
    "secondary": "snmp_trap_name"

There are probably better values that can be used to make the alerts in BP
more useful, but it will take someone with knowledge of the traps to know how
to set them.  For instance "vmwareAlertEntityName" is a varbind that might a 
better candidate for the primary property.

The status value for all traps is "critical".   Many vendors (like vmware) 
will incode the status of traps in the trap name itself like 
"vmwareTrapKPIPredictionClear".  A trap this with name should probably have a
status value of "ok".  The names can vary significantly with key words 
like Ok, Clear, Changed, Up/Down, etc. appended or embedded in the names. 
This is another area where someone with knowlege of the traps should go through 
and update the status setting.

For more information on BigPanda's SNMP event configs see this page:
https://docs.bigpanda.io/docs/snmp-simple-network-management-protocol#how-it-works
