_VmwNsxManagerTypeSeverity_type = {
  "1": "informational",
  "2": "low",
  "3": "medium",
  "4": "major",
  "5": "critical",
  "6": "high"
}

_vmwNsxMSnmpDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSnmpManagerConfigUpdated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpAddedBlackList_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpRemovedBlackList_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSsoConfigFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSsoUnconfigured_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUserRoleAssigned_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUserRoleUnassigned_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGroupRoleAssigned_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGroupRoleUnassigned_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVcLoginFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVcDisconnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLostVcConnectivity_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSsoDisconnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSsoTimeout_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFltrCnfgUpdateFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFltrCnfgNotAppliedToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFltrCnfgAppliedToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFltrCreatedForVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFltrDeletedForVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallConfigUpdateFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallRuleFailedVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallRuleAppliedVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrCnfgUpdateFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFlowMissed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardCnfgUpdateFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardApplied_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardDisableFail_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLegacyAppServiceDeletionFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallCpuThresholdCrossed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallMemThresholdCrossed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMConnPerSecThrshldCrossed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallCnfgUpdateTimedOut_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardCnfgUpdateTmOut_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallPublishFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrUpdatePublishFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardUpdatePublishFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMExcludeListPublishFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallCnfgUpdateOnDltCntnr_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMHostSyncFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMHostSynced_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallInstalled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallInstallFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallClusterInstalled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallClusterUninstalled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallClusterDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallForceSyncClusterFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallForceSyncClusterSuccess_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallVsfwdProcessStarted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallRulesetApplyAllFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallRulesetAppliedAll_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrCnfgApplyFailedToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrCnfgApplyAllFailedToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrCnfgAppliedAllToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardApplyAllFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSpoofGuardAppliedAll_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallTimeoutUpdateFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallTimeoutApplyFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallTimeoutApplied_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallTimeoutApplyAllFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallTimeoutAppliedAll_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCntnrCnfgAppliedToVnic_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallProcessMemoryThresholdCrossed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallCpuThresholdCrossCleared_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallMemThresholdCrossCleared_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMConnPerSecThrshldCrossCleared_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossCleared_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallProcessMemoryThresholdCrossCleared_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallThresholdConfigApplied_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallThresholdConfigApplyFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUnsupportedIPsetConfigured_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeNoVmServing_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeGatewayCreated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmBadState_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmCommFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmCnfgChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeGatewayDeleted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeGatewayReDeployed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmPowerOff_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeApplianceSizeChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeUpgrade51x_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeLicenseChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeApplianceMoved_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeApplianceNotFound_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVMHealthCheckMiss_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHealthCheckMiss_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeCommAgentNotConnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMApplianceWithDifferentId_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFirewallRuleModified_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeAntiAffinityRuleViolated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaEnabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeGatewayRecovered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmRecovered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeGatewayUpgraded_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmHlthChkDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgePrePublishFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeForcedSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmBooted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmInBadState_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmCpuUsageIncreased_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmMemUsageIncreased_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmProcessFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmSysTimeBad_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmSysTimeSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeAesniCryptoEngineUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeAesniCryptoEngineDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmOom_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeFileSysRo_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaCommDisconnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaSwitchOverSelf_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaSwitchOverActive_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaSwitchOverStandby_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeMonitorProcessFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLbVirtualServerPoolUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLbVirtualServerPoolDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLbVirtualServerPoolWrong_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLbPoolWarning_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecChannelUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecChannelDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecTunnelUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecTunnelDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecChannelUnknown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMIpsecTunnelUnknown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbMemberUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbMemberWarning_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbMemberDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbMemberUnknown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbPeerUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGlobalLbPeerDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDhcpServiceDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeResourceReservationFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeSplitBrainDetected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeSplitBrainRecovered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeSplitBrainRecoveryAttempt_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeResourceReservationSuccess_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeSddcChannelUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeSddcChannelDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeDuplicateIpDetected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeDuplicateIpResolved_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeBgpNeighborUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeBgpNeighborDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeBgpNeighborASMismatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborMTUMismatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborAreaIdMisMatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborHelloTimerMisMatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeOSPFNeighborDeadTimerMisMatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeL2vpnTunnelUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeL2vpnTunnelDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHAForceStandbyRemoved_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHAForceStandbyRemovalFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmBADStateRecovered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmBADStateAutoHealRecoveryDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaInUseVnicChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeHaCommConnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmRenameFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeBgpNeighborshipError_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmBadStateNotRecovered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeVmDcnOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeConsumedResourcesMissingInInventory_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeIpsecDeprecatedComplianceSuiteInUse_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeConnectedToMultipleTZHavingSameClusters_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEdgeConnectedToMultipleTZHavingDifferentClusters_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEndpointThinAgentEnabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGuestIntrspctnEnabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGuestIntrspctnIncompatibleEsx_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGuestIntrspctnEsxConnFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGuestIntrspctnStatusRcvFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEsxModuleEnabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEsxModuleUninstalled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMGuestIntrspctnHstMxMssngRep_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEndpointUndefined_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMEamGenericAlarm_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDplymntStatusChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDplymntUnitCreated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDplymntUnitUpdated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDplymntUnitDestroyed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDataStoreNotCnfgrdOnHost_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDplymntInstallationFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricAgentCreated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricAgentDestroyed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricSrvceNeedsRedplymnt_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUpgradeOfDplymntFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricDependenciesNotInstalled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricErrorNotifSecBfrUpgrade_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricErrCallbackNtRcvdUpgrade_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricErrCallbackNtRcvdUninstall_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricUninstallServiceFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricErrorNotifSecBfrUninstall_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricServerRebootUninstall_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricServerRebootUpgrade_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricConnEamFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricConnEamRestored_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricPreUninstallCleanUpFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricBackingEamNotFound_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricVibManualInstallationRequired_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFabricUninstallDeploymentUnit_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDepPluginIpPoolExhausted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDepPluginGenericAlarm_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDepPluginGenericException_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDepPluginVmReboot_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingConfigFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingReconfigFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingConfigFailedNotifSkip_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingInfraUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingInfraDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMMessagingDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerPolicyOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerPolicyDeleted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerFirewallPolicyOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerNetworkPolicyOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerGuestPolicyOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSync_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSyncRebootFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSyncDraftRollback_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSyncSectionDeletionFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSyncPrecedenceChangeFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServiceComposerOutOfSyncDraftSettingFailure_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMInconsistentSvmAlarm_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSvmRestartAlarm_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSvmAgentUnavailable_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVmAddedToSg_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVmRemovedFromSg_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMFullUniversalSyncFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSecondaryDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUniversalSyncFailedForEntity_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUniversalSyncStoppedOnSecondary_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUniversalSyncResumedOnSecondary_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMServerUp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMExtensionRegistered_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMExtensionUpdated_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDataSecScanStarted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDataSecScanEnded_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSamDataCollectionEnabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSamDataCollectionDisabled_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSamDataStoppedFlowing_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMSamDataResumedFlowing_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUsvmHeartbeatStopped_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUsvmHeartbeatResumed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUsvmReceivedHello_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMUpgradeSuccess_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMRestoreSuccess_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMDuplicateIp_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCPUHigh_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCPUNormal_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVirtualMachineMarkedAsSystemResource_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMScaleAboveSupportedLimits_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMScaleAboveThreshold_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMScaleNormalized_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMScaleNotEqualToRecommendedValue_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCertificateExpired_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMCertificateAboutToExpire_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanLogicalSwitchImproperlyCnfg_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanLogicalSwitchProperlyCnfg_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanInitFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanPortInitFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanInstanceDoesNotExist_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanLogicalSwitchWrkngImproperly_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanTransportZoneIncorrectlyWrkng_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanTransportZoneNotUsed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanOverlayClassMissingOnDvs_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerRemoved_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerConnProblem_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerInactive_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerActive_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanVmknicMissingOrDeleted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanInfo_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanVmknicPortGrpMissing_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanVmknicPortGrpAppears_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanConnDown_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMBackingPortgroupMissing_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMBackingPortgroupReappears_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMManagedObjectIdChanged_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMHighLatencyOnDisk_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMHighLatencyOnDiskResolved_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMControllerVmPoweredOff_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMControllerVmDeleted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanConfigNotSet_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanPortgroupDeleted_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanVDSandPgMismatch_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerDisconnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerConnected_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanControllerVmPoweredOn_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMVxlanHostEvents_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMLogserverEventGenStopped_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMApplicationRuleManagerFlowAnalysisStart_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMApplicationRuleManagerFlowAnalysisFailed_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}
_vmwNsxMApplicationRuleManagerFlowAnalysisComplete_vbinds = {
  "vmwNsxMEventSeverity" : _VmwNsxManagerTypeSeverity_type
}

traps = {
  "vmwNsxMSnmpDisabled" : _vmwNsxMSnmpDisabled_vbinds,
  "vmwNsxMSnmpManagerConfigUpdated" : _vmwNsxMSnmpManagerConfigUpdated_vbinds,
  "vmwNsxMIpAddedBlackList" : _vmwNsxMIpAddedBlackList_vbinds,
  "vmwNsxMIpRemovedBlackList" : _vmwNsxMIpRemovedBlackList_vbinds,
  "vmwNsxMSsoConfigFailure" : _vmwNsxMSsoConfigFailure_vbinds,
  "vmwNsxMSsoUnconfigured" : _vmwNsxMSsoUnconfigured_vbinds,
  "vmwNsxMUserRoleAssigned" : _vmwNsxMUserRoleAssigned_vbinds,
  "vmwNsxMUserRoleUnassigned" : _vmwNsxMUserRoleUnassigned_vbinds,
  "vmwNsxMGroupRoleAssigned" : _vmwNsxMGroupRoleAssigned_vbinds,
  "vmwNsxMGroupRoleUnassigned" : _vmwNsxMGroupRoleUnassigned_vbinds,
  "vmwNsxMVcLoginFailed" : _vmwNsxMVcLoginFailed_vbinds,
  "vmwNsxMVcDisconnected" : _vmwNsxMVcDisconnected_vbinds,
  "vmwNsxMLostVcConnectivity" : _vmwNsxMLostVcConnectivity_vbinds,
  "vmwNsxMSsoDisconnected" : _vmwNsxMSsoDisconnected_vbinds,
  "vmwNsxMSsoTimeout" : _vmwNsxMSsoTimeout_vbinds,
  "vmwNsxMFltrCnfgUpdateFailed" : _vmwNsxMFltrCnfgUpdateFailed_vbinds,
  "vmwNsxMFltrCnfgNotAppliedToVnic" : _vmwNsxMFltrCnfgNotAppliedToVnic_vbinds,
  "vmwNsxMFltrCnfgAppliedToVnic" : _vmwNsxMFltrCnfgAppliedToVnic_vbinds,
  "vmwNsxMFltrCreatedForVnic" : _vmwNsxMFltrCreatedForVnic_vbinds,
  "vmwNsxMFltrDeletedForVnic" : _vmwNsxMFltrDeletedForVnic_vbinds,
  "vmwNsxMFirewallConfigUpdateFailed" : _vmwNsxMFirewallConfigUpdateFailed_vbinds,
  "vmwNsxMFirewallRuleFailedVnic" : _vmwNsxMFirewallRuleFailedVnic_vbinds,
  "vmwNsxMFirewallRuleAppliedVnic" : _vmwNsxMFirewallRuleAppliedVnic_vbinds,
  "vmwNsxMCntnrCnfgUpdateFailed" : _vmwNsxMCntnrCnfgUpdateFailed_vbinds,
  "vmwNsxMFlowMissed" : _vmwNsxMFlowMissed_vbinds,
  "vmwNsxMSpoofGuardCnfgUpdateFailed" : _vmwNsxMSpoofGuardCnfgUpdateFailed_vbinds,
  "vmwNsxMSpoofGuardFailed" : _vmwNsxMSpoofGuardFailed_vbinds,
  "vmwNsxMSpoofGuardApplied" : _vmwNsxMSpoofGuardApplied_vbinds,
  "vmwNsxMSpoofGuardDisableFail" : _vmwNsxMSpoofGuardDisableFail_vbinds,
  "vmwNsxMSpoofGuardDisabled" : _vmwNsxMSpoofGuardDisabled_vbinds,
  "vmwNsxMLegacyAppServiceDeletionFailed" : _vmwNsxMLegacyAppServiceDeletionFailed_vbinds,
  "vmwNsxMFirewallCpuThresholdCrossed" : _vmwNsxMFirewallCpuThresholdCrossed_vbinds,
  "vmwNsxMFirewallMemThresholdCrossed" : _vmwNsxMFirewallMemThresholdCrossed_vbinds,
  "vmwNsxMConnPerSecThrshldCrossed" : _vmwNsxMConnPerSecThrshldCrossed_vbinds,
  "vmwNsxMFirewallCnfgUpdateTimedOut" : _vmwNsxMFirewallCnfgUpdateTimedOut_vbinds,
  "vmwNsxMSpoofGuardCnfgUpdateTmOut" : _vmwNsxMSpoofGuardCnfgUpdateTmOut_vbinds,
  "vmwNsxMFirewallPublishFailed" : _vmwNsxMFirewallPublishFailed_vbinds,
  "vmwNsxMCntnrUpdatePublishFailed" : _vmwNsxMCntnrUpdatePublishFailed_vbinds,
  "vmwNsxMSpoofGuardUpdatePublishFailed" : _vmwNsxMSpoofGuardUpdatePublishFailed_vbinds,
  "vmwNsxMExcludeListPublishFailed" : _vmwNsxMExcludeListPublishFailed_vbinds,
  "vmwNsxMFirewallCnfgUpdateOnDltCntnr" : _vmwNsxMFirewallCnfgUpdateOnDltCntnr_vbinds,
  "vmwNsxMHostSyncFailed" : _vmwNsxMHostSyncFailed_vbinds,
  "vmwNsxMHostSynced" : _vmwNsxMHostSynced_vbinds,
  "vmwNsxMFirewallInstalled" : _vmwNsxMFirewallInstalled_vbinds,
  "vmwNsxMFirewallInstallFailed" : _vmwNsxMFirewallInstallFailed_vbinds,
  "vmwNsxMFirewallClusterInstalled" : _vmwNsxMFirewallClusterInstalled_vbinds,
  "vmwNsxMFirewallClusterUninstalled" : _vmwNsxMFirewallClusterUninstalled_vbinds,
  "vmwNsxMFirewallClusterDisabled" : _vmwNsxMFirewallClusterDisabled_vbinds,
  "vmwNsxMFirewallForceSyncClusterFailed" : _vmwNsxMFirewallForceSyncClusterFailed_vbinds,
  "vmwNsxMFirewallForceSyncClusterSuccess" : _vmwNsxMFirewallForceSyncClusterSuccess_vbinds,
  "vmwNsxMFirewallVsfwdProcessStarted" : _vmwNsxMFirewallVsfwdProcessStarted_vbinds,
  "vmwNsxMFirewallRulesetApplyAllFailed" : _vmwNsxMFirewallRulesetApplyAllFailed_vbinds,
  "vmwNsxMFirewallRulesetAppliedAll" : _vmwNsxMFirewallRulesetAppliedAll_vbinds,
  "vmwNsxMCntnrCnfgApplyFailedToVnic" : _vmwNsxMCntnrCnfgApplyFailedToVnic_vbinds,
  "vmwNsxMCntnrCnfgApplyAllFailedToVnic" : _vmwNsxMCntnrCnfgApplyAllFailedToVnic_vbinds,
  "vmwNsxMCntnrCnfgAppliedAllToVnic" : _vmwNsxMCntnrCnfgAppliedAllToVnic_vbinds,
  "vmwNsxMSpoofGuardApplyAllFailed" : _vmwNsxMSpoofGuardApplyAllFailed_vbinds,
  "vmwNsxMSpoofGuardAppliedAll" : _vmwNsxMSpoofGuardAppliedAll_vbinds,
  "vmwNsxMFirewallTimeoutUpdateFailed" : _vmwNsxMFirewallTimeoutUpdateFailed_vbinds,
  "vmwNsxMFirewallTimeoutApplyFailed" : _vmwNsxMFirewallTimeoutApplyFailed_vbinds,
  "vmwNsxMFirewallTimeoutApplied" : _vmwNsxMFirewallTimeoutApplied_vbinds,
  "vmwNsxMFirewallTimeoutApplyAllFailed" : _vmwNsxMFirewallTimeoutApplyAllFailed_vbinds,
  "vmwNsxMFirewallTimeoutAppliedAll" : _vmwNsxMFirewallTimeoutAppliedAll_vbinds,
  "vmwNsxMCntnrCnfgAppliedToVnic" : _vmwNsxMCntnrCnfgAppliedToVnic_vbinds,
  "vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossed" : _vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossed_vbinds,
  "vmwNsxMFirewallProcessMemoryThresholdCrossed" : _vmwNsxMFirewallProcessMemoryThresholdCrossed_vbinds,
  "vmwNsxMFirewallCpuThresholdCrossCleared" : _vmwNsxMFirewallCpuThresholdCrossCleared_vbinds,
  "vmwNsxMFirewallMemThresholdCrossCleared" : _vmwNsxMFirewallMemThresholdCrossCleared_vbinds,
  "vmwNsxMConnPerSecThrshldCrossCleared" : _vmwNsxMConnPerSecThrshldCrossCleared_vbinds,
  "vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossCleared" : _vmwNsxMFirewallMaxConcurrentConnectionsThresholdCrossCleared_vbinds,
  "vmwNsxMFirewallProcessMemoryThresholdCrossCleared" : _vmwNsxMFirewallProcessMemoryThresholdCrossCleared_vbinds,
  "vmwNsxMFirewallThresholdConfigApplied" : _vmwNsxMFirewallThresholdConfigApplied_vbinds,
  "vmwNsxMFirewallThresholdConfigApplyFailed" : _vmwNsxMFirewallThresholdConfigApplyFailed_vbinds,
  "vmwNsxMUnsupportedIPsetConfigured" : _vmwNsxMUnsupportedIPsetConfigured_vbinds,
  "vmwNsxMEdgeNoVmServing" : _vmwNsxMEdgeNoVmServing_vbinds,
  "vmwNsxMEdgeGatewayCreated" : _vmwNsxMEdgeGatewayCreated_vbinds,
  "vmwNsxMEdgeVmBadState" : _vmwNsxMEdgeVmBadState_vbinds,
  "vmwNsxMEdgeVmCommFailed" : _vmwNsxMEdgeVmCommFailed_vbinds,
  "vmwNsxMEdgeVmCnfgChanged" : _vmwNsxMEdgeVmCnfgChanged_vbinds,
  "vmwNsxMEdgeGatewayDeleted" : _vmwNsxMEdgeGatewayDeleted_vbinds,
  "vmwNsxMEdgeGatewayReDeployed" : _vmwNsxMEdgeGatewayReDeployed_vbinds,
  "vmwNsxMEdgeVmPowerOff" : _vmwNsxMEdgeVmPowerOff_vbinds,
  "vmwNsxMEdgeApplianceSizeChanged" : _vmwNsxMEdgeApplianceSizeChanged_vbinds,
  "vmwNsxMEdgeUpgrade51x" : _vmwNsxMEdgeUpgrade51x_vbinds,
  "vmwNsxMEdgeLicenseChanged" : _vmwNsxMEdgeLicenseChanged_vbinds,
  "vmwNsxMEdgeApplianceMoved" : _vmwNsxMEdgeApplianceMoved_vbinds,
  "vmwNsxMEdgeApplianceNotFound" : _vmwNsxMEdgeApplianceNotFound_vbinds,
  "vmwNsxMEdgeVMHealthCheckMiss" : _vmwNsxMEdgeVMHealthCheckMiss_vbinds,
  "vmwNsxMEdgeHealthCheckMiss" : _vmwNsxMEdgeHealthCheckMiss_vbinds,
  "vmwNsxMEdgeCommAgentNotConnected" : _vmwNsxMEdgeCommAgentNotConnected_vbinds,
  "vmwNsxMApplianceWithDifferentId" : _vmwNsxMApplianceWithDifferentId_vbinds,
  "vmwNsxMFirewallRuleModified" : _vmwNsxMFirewallRuleModified_vbinds,
  "vmwNsxMEdgeAntiAffinityRuleViolated" : _vmwNsxMEdgeAntiAffinityRuleViolated_vbinds,
  "vmwNsxMEdgeHaEnabled" : _vmwNsxMEdgeHaEnabled_vbinds,
  "vmwNsxMEdgeHaDisabled" : _vmwNsxMEdgeHaDisabled_vbinds,
  "vmwNsxMEdgeGatewayRecovered" : _vmwNsxMEdgeGatewayRecovered_vbinds,
  "vmwNsxMEdgeVmRecovered" : _vmwNsxMEdgeVmRecovered_vbinds,
  "vmwNsxMEdgeGatewayUpgraded" : _vmwNsxMEdgeGatewayUpgraded_vbinds,
  "vmwNsxMEdgeVmHlthChkDisabled" : _vmwNsxMEdgeVmHlthChkDisabled_vbinds,
  "vmwNsxMEdgePrePublishFailed" : _vmwNsxMEdgePrePublishFailed_vbinds,
  "vmwNsxMEdgeForcedSync" : _vmwNsxMEdgeForcedSync_vbinds,
  "vmwNsxMEdgeVmBooted" : _vmwNsxMEdgeVmBooted_vbinds,
  "vmwNsxMEdgeVmInBadState" : _vmwNsxMEdgeVmInBadState_vbinds,
  "vmwNsxMEdgeVmCpuUsageIncreased" : _vmwNsxMEdgeVmCpuUsageIncreased_vbinds,
  "vmwNsxMEdgeVmMemUsageIncreased" : _vmwNsxMEdgeVmMemUsageIncreased_vbinds,
  "vmwNsxMEdgeVmProcessFailure" : _vmwNsxMEdgeVmProcessFailure_vbinds,
  "vmwNsxMEdgeVmSysTimeBad" : _vmwNsxMEdgeVmSysTimeBad_vbinds,
  "vmwNsxMEdgeVmSysTimeSync" : _vmwNsxMEdgeVmSysTimeSync_vbinds,
  "vmwNsxMEdgeAesniCryptoEngineUp" : _vmwNsxMEdgeAesniCryptoEngineUp_vbinds,
  "vmwNsxMEdgeAesniCryptoEngineDown" : _vmwNsxMEdgeAesniCryptoEngineDown_vbinds,
  "vmwNsxMEdgeVmOom" : _vmwNsxMEdgeVmOom_vbinds,
  "vmwNsxMEdgeFileSysRo" : _vmwNsxMEdgeFileSysRo_vbinds,
  "vmwNsxMEdgeHaCommDisconnected" : _vmwNsxMEdgeHaCommDisconnected_vbinds,
  "vmwNsxMEdgeHaSwitchOverSelf" : _vmwNsxMEdgeHaSwitchOverSelf_vbinds,
  "vmwNsxMEdgeHaSwitchOverActive" : _vmwNsxMEdgeHaSwitchOverActive_vbinds,
  "vmwNsxMEdgeHaSwitchOverStandby" : _vmwNsxMEdgeHaSwitchOverStandby_vbinds,
  "vmwNsxMEdgeMonitorProcessFailure" : _vmwNsxMEdgeMonitorProcessFailure_vbinds,
  "vmwNsxMLbVirtualServerPoolUp" : _vmwNsxMLbVirtualServerPoolUp_vbinds,
  "vmwNsxMLbVirtualServerPoolDown" : _vmwNsxMLbVirtualServerPoolDown_vbinds,
  "vmwNsxMLbVirtualServerPoolWrong" : _vmwNsxMLbVirtualServerPoolWrong_vbinds,
  "vmwNsxMLbPoolWarning" : _vmwNsxMLbPoolWarning_vbinds,
  "vmwNsxMIpsecChannelUp" : _vmwNsxMIpsecChannelUp_vbinds,
  "vmwNsxMIpsecChannelDown" : _vmwNsxMIpsecChannelDown_vbinds,
  "vmwNsxMIpsecTunnelUp" : _vmwNsxMIpsecTunnelUp_vbinds,
  "vmwNsxMIpsecTunnelDown" : _vmwNsxMIpsecTunnelDown_vbinds,
  "vmwNsxMIpsecChannelUnknown" : _vmwNsxMIpsecChannelUnknown_vbinds,
  "vmwNsxMIpsecTunnelUnknown" : _vmwNsxMIpsecTunnelUnknown_vbinds,
  "vmwNsxMGlobalLbMemberUp" : _vmwNsxMGlobalLbMemberUp_vbinds,
  "vmwNsxMGlobalLbMemberWarning" : _vmwNsxMGlobalLbMemberWarning_vbinds,
  "vmwNsxMGlobalLbMemberDown" : _vmwNsxMGlobalLbMemberDown_vbinds,
  "vmwNsxMGlobalLbMemberUnknown" : _vmwNsxMGlobalLbMemberUnknown_vbinds,
  "vmwNsxMGlobalLbPeerUp" : _vmwNsxMGlobalLbPeerUp_vbinds,
  "vmwNsxMGlobalLbPeerDown" : _vmwNsxMGlobalLbPeerDown_vbinds,
  "vmwNsxMDhcpServiceDisabled" : _vmwNsxMDhcpServiceDisabled_vbinds,
  "vmwNsxMEdgeResourceReservationFailure" : _vmwNsxMEdgeResourceReservationFailure_vbinds,
  "vmwNsxMEdgeSplitBrainDetected" : _vmwNsxMEdgeSplitBrainDetected_vbinds,
  "vmwNsxMEdgeSplitBrainRecovered" : _vmwNsxMEdgeSplitBrainRecovered_vbinds,
  "vmwNsxMEdgeSplitBrainRecoveryAttempt" : _vmwNsxMEdgeSplitBrainRecoveryAttempt_vbinds,
  "vmwNsxMEdgeResourceReservationSuccess" : _vmwNsxMEdgeResourceReservationSuccess_vbinds,
  "vmwNsxMEdgeSddcChannelUp" : _vmwNsxMEdgeSddcChannelUp_vbinds,
  "vmwNsxMEdgeSddcChannelDown" : _vmwNsxMEdgeSddcChannelDown_vbinds,
  "vmwNsxMEdgeDuplicateIpDetected" : _vmwNsxMEdgeDuplicateIpDetected_vbinds,
  "vmwNsxMEdgeDuplicateIpResolved" : _vmwNsxMEdgeDuplicateIpResolved_vbinds,
  "vmwNsxMEdgeBgpNeighborUp" : _vmwNsxMEdgeBgpNeighborUp_vbinds,
  "vmwNsxMEdgeBgpNeighborDown" : _vmwNsxMEdgeBgpNeighborDown_vbinds,
  "vmwNsxMEdgeBgpNeighborASMismatch" : _vmwNsxMEdgeBgpNeighborASMismatch_vbinds,
  "vmwNsxMEdgeOSPFNeighborUp" : _vmwNsxMEdgeOSPFNeighborUp_vbinds,
  "vmwNsxMEdgeOSPFNeighborDown" : _vmwNsxMEdgeOSPFNeighborDown_vbinds,
  "vmwNsxMEdgeOSPFNeighborMTUMismatch" : _vmwNsxMEdgeOSPFNeighborMTUMismatch_vbinds,
  "vmwNsxMEdgeOSPFNeighborAreaIdMisMatch" : _vmwNsxMEdgeOSPFNeighborAreaIdMisMatch_vbinds,
  "vmwNsxMEdgeOSPFNeighborHelloTimerMisMatch" : _vmwNsxMEdgeOSPFNeighborHelloTimerMisMatch_vbinds,
  "vmwNsxMEdgeOSPFNeighborDeadTimerMisMatch" : _vmwNsxMEdgeOSPFNeighborDeadTimerMisMatch_vbinds,
  "vmwNsxMEdgeL2vpnTunnelUp" : _vmwNsxMEdgeL2vpnTunnelUp_vbinds,
  "vmwNsxMEdgeL2vpnTunnelDown" : _vmwNsxMEdgeL2vpnTunnelDown_vbinds,
  "vmwNsxMEdgeHAForceStandbyRemoved" : _vmwNsxMEdgeHAForceStandbyRemoved_vbinds,
  "vmwNsxMEdgeHAForceStandbyRemovalFailed" : _vmwNsxMEdgeHAForceStandbyRemovalFailed_vbinds,
  "vmwNsxMEdgeVmBADStateRecovered" : _vmwNsxMEdgeVmBADStateRecovered_vbinds,
  "vmwNsxMEdgeVmBADStateAutoHealRecoveryDisabled" : _vmwNsxMEdgeVmBADStateAutoHealRecoveryDisabled_vbinds,
  "vmwNsxMEdgeHaInUseVnicChanged" : _vmwNsxMEdgeHaInUseVnicChanged_vbinds,
  "vmwNsxMEdgeHaCommConnected" : _vmwNsxMEdgeHaCommConnected_vbinds,
  "vmwNsxMEdgeVmRenameFailed" : _vmwNsxMEdgeVmRenameFailed_vbinds,
  "vmwNsxMEdgeBgpNeighborshipError" : _vmwNsxMEdgeBgpNeighborshipError_vbinds,
  "vmwNsxMEdgeVmBadStateNotRecovered" : _vmwNsxMEdgeVmBadStateNotRecovered_vbinds,
  "vmwNsxMEdgeVmDcnOutOfSync" : _vmwNsxMEdgeVmDcnOutOfSync_vbinds,
  "vmwNsxMEdgeConsumedResourcesMissingInInventory" : _vmwNsxMEdgeConsumedResourcesMissingInInventory_vbinds,
  "vmwNsxMEdgeIpsecDeprecatedComplianceSuiteInUse" : _vmwNsxMEdgeIpsecDeprecatedComplianceSuiteInUse_vbinds,
  "vmwNsxMEdgeConnectedToMultipleTZHavingSameClusters" : _vmwNsxMEdgeConnectedToMultipleTZHavingSameClusters_vbinds,
  "vmwNsxMEdgeConnectedToMultipleTZHavingDifferentClusters" : _vmwNsxMEdgeConnectedToMultipleTZHavingDifferentClusters_vbinds,
  "vmwNsxMEndpointThinAgentEnabled" : _vmwNsxMEndpointThinAgentEnabled_vbinds,
  "vmwNsxMGuestIntrspctnEnabled" : _vmwNsxMGuestIntrspctnEnabled_vbinds,
  "vmwNsxMGuestIntrspctnIncompatibleEsx" : _vmwNsxMGuestIntrspctnIncompatibleEsx_vbinds,
  "vmwNsxMGuestIntrspctnEsxConnFailed" : _vmwNsxMGuestIntrspctnEsxConnFailed_vbinds,
  "vmwNsxMGuestIntrspctnStatusRcvFailed" : _vmwNsxMGuestIntrspctnStatusRcvFailed_vbinds,
  "vmwNsxMEsxModuleEnabled" : _vmwNsxMEsxModuleEnabled_vbinds,
  "vmwNsxMEsxModuleUninstalled" : _vmwNsxMEsxModuleUninstalled_vbinds,
  "vmwNsxMGuestIntrspctnHstMxMssngRep" : _vmwNsxMGuestIntrspctnHstMxMssngRep_vbinds,
  "vmwNsxMEndpointUndefined" : _vmwNsxMEndpointUndefined_vbinds,
  "vmwNsxMEamGenericAlarm" : _vmwNsxMEamGenericAlarm_vbinds,
  "vmwNsxMFabricDplymntStatusChanged" : _vmwNsxMFabricDplymntStatusChanged_vbinds,
  "vmwNsxMFabricDplymntUnitCreated" : _vmwNsxMFabricDplymntUnitCreated_vbinds,
  "vmwNsxMFabricDplymntUnitUpdated" : _vmwNsxMFabricDplymntUnitUpdated_vbinds,
  "vmwNsxMFabricDplymntUnitDestroyed" : _vmwNsxMFabricDplymntUnitDestroyed_vbinds,
  "vmwNsxMDataStoreNotCnfgrdOnHost" : _vmwNsxMDataStoreNotCnfgrdOnHost_vbinds,
  "vmwNsxMFabricDplymntInstallationFailed" : _vmwNsxMFabricDplymntInstallationFailed_vbinds,
  "vmwNsxMFabricAgentCreated" : _vmwNsxMFabricAgentCreated_vbinds,
  "vmwNsxMFabricAgentDestroyed" : _vmwNsxMFabricAgentDestroyed_vbinds,
  "vmwNsxMFabricSrvceNeedsRedplymnt" : _vmwNsxMFabricSrvceNeedsRedplymnt_vbinds,
  "vmwNsxMUpgradeOfDplymntFailed" : _vmwNsxMUpgradeOfDplymntFailed_vbinds,
  "vmwNsxMFabricDependenciesNotInstalled" : _vmwNsxMFabricDependenciesNotInstalled_vbinds,
  "vmwNsxMFabricErrorNotifSecBfrUpgrade" : _vmwNsxMFabricErrorNotifSecBfrUpgrade_vbinds,
  "vmwNsxMFabricErrCallbackNtRcvdUpgrade" : _vmwNsxMFabricErrCallbackNtRcvdUpgrade_vbinds,
  "vmwNsxMFabricErrCallbackNtRcvdUninstall" : _vmwNsxMFabricErrCallbackNtRcvdUninstall_vbinds,
  "vmwNsxMFabricUninstallServiceFailed" : _vmwNsxMFabricUninstallServiceFailed_vbinds,
  "vmwNsxMFabricErrorNotifSecBfrUninstall" : _vmwNsxMFabricErrorNotifSecBfrUninstall_vbinds,
  "vmwNsxMFabricServerRebootUninstall" : _vmwNsxMFabricServerRebootUninstall_vbinds,
  "vmwNsxMFabricServerRebootUpgrade" : _vmwNsxMFabricServerRebootUpgrade_vbinds,
  "vmwNsxMFabricConnEamFailed" : _vmwNsxMFabricConnEamFailed_vbinds,
  "vmwNsxMFabricConnEamRestored" : _vmwNsxMFabricConnEamRestored_vbinds,
  "vmwNsxMFabricPreUninstallCleanUpFailed" : _vmwNsxMFabricPreUninstallCleanUpFailed_vbinds,
  "vmwNsxMFabricBackingEamNotFound" : _vmwNsxMFabricBackingEamNotFound_vbinds,
  "vmwNsxMFabricVibManualInstallationRequired" : _vmwNsxMFabricVibManualInstallationRequired_vbinds,
  "vmwNsxMFabricUninstallDeploymentUnit" : _vmwNsxMFabricUninstallDeploymentUnit_vbinds,
  "vmwNsxMDepPluginIpPoolExhausted" : _vmwNsxMDepPluginIpPoolExhausted_vbinds,
  "vmwNsxMDepPluginGenericAlarm" : _vmwNsxMDepPluginGenericAlarm_vbinds,
  "vmwNsxMDepPluginGenericException" : _vmwNsxMDepPluginGenericException_vbinds,
  "vmwNsxMDepPluginVmReboot" : _vmwNsxMDepPluginVmReboot_vbinds,
  "vmwNsxMMessagingConfigFailed" : _vmwNsxMMessagingConfigFailed_vbinds,
  "vmwNsxMMessagingReconfigFailed" : _vmwNsxMMessagingReconfigFailed_vbinds,
  "vmwNsxMMessagingConfigFailedNotifSkip" : _vmwNsxMMessagingConfigFailedNotifSkip_vbinds,
  "vmwNsxMMessagingInfraUp" : _vmwNsxMMessagingInfraUp_vbinds,
  "vmwNsxMMessagingInfraDown" : _vmwNsxMMessagingInfraDown_vbinds,
  "vmwNsxMMessagingDisabled" : _vmwNsxMMessagingDisabled_vbinds,
  "vmwNsxMServiceComposerPolicyOutOfSync" : _vmwNsxMServiceComposerPolicyOutOfSync_vbinds,
  "vmwNsxMServiceComposerPolicyDeleted" : _vmwNsxMServiceComposerPolicyDeleted_vbinds,
  "vmwNsxMServiceComposerFirewallPolicyOutOfSync" : _vmwNsxMServiceComposerFirewallPolicyOutOfSync_vbinds,
  "vmwNsxMServiceComposerNetworkPolicyOutOfSync" : _vmwNsxMServiceComposerNetworkPolicyOutOfSync_vbinds,
  "vmwNsxMServiceComposerGuestPolicyOutOfSync" : _vmwNsxMServiceComposerGuestPolicyOutOfSync_vbinds,
  "vmwNsxMServiceComposerOutOfSync" : _vmwNsxMServiceComposerOutOfSync_vbinds,
  "vmwNsxMServiceComposerOutOfSyncRebootFailure" : _vmwNsxMServiceComposerOutOfSyncRebootFailure_vbinds,
  "vmwNsxMServiceComposerOutOfSyncDraftRollback" : _vmwNsxMServiceComposerOutOfSyncDraftRollback_vbinds,
  "vmwNsxMServiceComposerOutOfSyncSectionDeletionFailure" : _vmwNsxMServiceComposerOutOfSyncSectionDeletionFailure_vbinds,
  "vmwNsxMServiceComposerOutOfSyncPrecedenceChangeFailure" : _vmwNsxMServiceComposerOutOfSyncPrecedenceChangeFailure_vbinds,
  "vmwNsxMServiceComposerOutOfSyncDraftSettingFailure" : _vmwNsxMServiceComposerOutOfSyncDraftSettingFailure_vbinds,
  "vmwNsxMInconsistentSvmAlarm" : _vmwNsxMInconsistentSvmAlarm_vbinds,
  "vmwNsxMSvmRestartAlarm" : _vmwNsxMSvmRestartAlarm_vbinds,
  "vmwNsxMSvmAgentUnavailable" : _vmwNsxMSvmAgentUnavailable_vbinds,
  "vmwNsxMVmAddedToSg" : _vmwNsxMVmAddedToSg_vbinds,
  "vmwNsxMVmRemovedFromSg" : _vmwNsxMVmRemovedFromSg_vbinds,
  "vmwNsxMFullUniversalSyncFailed" : _vmwNsxMFullUniversalSyncFailed_vbinds,
  "vmwNsxMSecondaryDown" : _vmwNsxMSecondaryDown_vbinds,
  "vmwNsxMUniversalSyncFailedForEntity" : _vmwNsxMUniversalSyncFailedForEntity_vbinds,
  "vmwNsxMUniversalSyncStoppedOnSecondary" : _vmwNsxMUniversalSyncStoppedOnSecondary_vbinds,
  "vmwNsxMUniversalSyncResumedOnSecondary" : _vmwNsxMUniversalSyncResumedOnSecondary_vbinds,
  "vmwNsxMServerUp" : _vmwNsxMServerUp_vbinds,
  "vmwNsxMExtensionRegistered" : _vmwNsxMExtensionRegistered_vbinds,
  "vmwNsxMExtensionUpdated" : _vmwNsxMExtensionUpdated_vbinds,
  "vmwNsxMDataSecScanStarted" : _vmwNsxMDataSecScanStarted_vbinds,
  "vmwNsxMDataSecScanEnded" : _vmwNsxMDataSecScanEnded_vbinds,
  "vmwNsxMSamDataCollectionEnabled" : _vmwNsxMSamDataCollectionEnabled_vbinds,
  "vmwNsxMSamDataCollectionDisabled" : _vmwNsxMSamDataCollectionDisabled_vbinds,
  "vmwNsxMSamDataStoppedFlowing" : _vmwNsxMSamDataStoppedFlowing_vbinds,
  "vmwNsxMSamDataResumedFlowing" : _vmwNsxMSamDataResumedFlowing_vbinds,
  "vmwNsxMUsvmHeartbeatStopped" : _vmwNsxMUsvmHeartbeatStopped_vbinds,
  "vmwNsxMUsvmHeartbeatResumed" : _vmwNsxMUsvmHeartbeatResumed_vbinds,
  "vmwNsxMUsvmReceivedHello" : _vmwNsxMUsvmReceivedHello_vbinds,
  "vmwNsxMUpgradeSuccess" : _vmwNsxMUpgradeSuccess_vbinds,
  "vmwNsxMRestoreSuccess" : _vmwNsxMRestoreSuccess_vbinds,
  "vmwNsxMDuplicateIp" : _vmwNsxMDuplicateIp_vbinds,
  "vmwNsxMCPUHigh" : _vmwNsxMCPUHigh_vbinds,
  "vmwNsxMCPUNormal" : _vmwNsxMCPUNormal_vbinds,
  "vmwNsxMVirtualMachineMarkedAsSystemResource" : _vmwNsxMVirtualMachineMarkedAsSystemResource_vbinds,
  "vmwNsxMScaleAboveSupportedLimits" : _vmwNsxMScaleAboveSupportedLimits_vbinds,
  "vmwNsxMScaleAboveThreshold" : _vmwNsxMScaleAboveThreshold_vbinds,
  "vmwNsxMScaleNormalized" : _vmwNsxMScaleNormalized_vbinds,
  "vmwNsxMScaleNotEqualToRecommendedValue" : _vmwNsxMScaleNotEqualToRecommendedValue_vbinds,
  "vmwNsxMCertificateExpired" : _vmwNsxMCertificateExpired_vbinds,
  "vmwNsxMCertificateAboutToExpire" : _vmwNsxMCertificateAboutToExpire_vbinds,
  "vmwNsxMVxlanLogicalSwitchImproperlyCnfg" : _vmwNsxMVxlanLogicalSwitchImproperlyCnfg_vbinds,
  "vmwNsxMVxlanLogicalSwitchProperlyCnfg" : _vmwNsxMVxlanLogicalSwitchProperlyCnfg_vbinds,
  "vmwNsxMVxlanInitFailed" : _vmwNsxMVxlanInitFailed_vbinds,
  "vmwNsxMVxlanPortInitFailed" : _vmwNsxMVxlanPortInitFailed_vbinds,
  "vmwNsxMVxlanInstanceDoesNotExist" : _vmwNsxMVxlanInstanceDoesNotExist_vbinds,
  "vmwNsxMVxlanLogicalSwitchWrkngImproperly" : _vmwNsxMVxlanLogicalSwitchWrkngImproperly_vbinds,
  "vmwNsxMVxlanTransportZoneIncorrectlyWrkng" : _vmwNsxMVxlanTransportZoneIncorrectlyWrkng_vbinds,
  "vmwNsxMVxlanTransportZoneNotUsed" : _vmwNsxMVxlanTransportZoneNotUsed_vbinds,
  "vmwNsxMVxlanOverlayClassMissingOnDvs" : _vmwNsxMVxlanOverlayClassMissingOnDvs_vbinds,
  "vmwNsxMVxlanControllerRemoved" : _vmwNsxMVxlanControllerRemoved_vbinds,
  "vmwNsxMVxlanControllerConnProblem" : _vmwNsxMVxlanControllerConnProblem_vbinds,
  "vmwNsxMVxlanControllerInactive" : _vmwNsxMVxlanControllerInactive_vbinds,
  "vmwNsxMVxlanControllerActive" : _vmwNsxMVxlanControllerActive_vbinds,
  "vmwNsxMVxlanVmknicMissingOrDeleted" : _vmwNsxMVxlanVmknicMissingOrDeleted_vbinds,
  "vmwNsxMVxlanInfo" : _vmwNsxMVxlanInfo_vbinds,
  "vmwNsxMVxlanVmknicPortGrpMissing" : _vmwNsxMVxlanVmknicPortGrpMissing_vbinds,
  "vmwNsxMVxlanVmknicPortGrpAppears" : _vmwNsxMVxlanVmknicPortGrpAppears_vbinds,
  "vmwNsxMVxlanConnDown" : _vmwNsxMVxlanConnDown_vbinds,
  "vmwNsxMBackingPortgroupMissing" : _vmwNsxMBackingPortgroupMissing_vbinds,
  "vmwNsxMBackingPortgroupReappears" : _vmwNsxMBackingPortgroupReappears_vbinds,
  "vmwNsxMManagedObjectIdChanged" : _vmwNsxMManagedObjectIdChanged_vbinds,
  "vmwNsxMHighLatencyOnDisk" : _vmwNsxMHighLatencyOnDisk_vbinds,
  "vmwNsxMHighLatencyOnDiskResolved" : _vmwNsxMHighLatencyOnDiskResolved_vbinds,
  "vmwNsxMControllerVmPoweredOff" : _vmwNsxMControllerVmPoweredOff_vbinds,
  "vmwNsxMControllerVmDeleted" : _vmwNsxMControllerVmDeleted_vbinds,
  "vmwNsxMVxlanConfigNotSet" : _vmwNsxMVxlanConfigNotSet_vbinds,
  "vmwNsxMVxlanPortgroupDeleted" : _vmwNsxMVxlanPortgroupDeleted_vbinds,
  "vmwNsxMVxlanVDSandPgMismatch" : _vmwNsxMVxlanVDSandPgMismatch_vbinds,
  "vmwNsxMVxlanControllerDisconnected" : _vmwNsxMVxlanControllerDisconnected_vbinds,
  "vmwNsxMVxlanControllerConnected" : _vmwNsxMVxlanControllerConnected_vbinds,
  "vmwNsxMVxlanControllerVmPoweredOn" : _vmwNsxMVxlanControllerVmPoweredOn_vbinds,
  "vmwNsxMVxlanHostEvents" : _vmwNsxMVxlanHostEvents_vbinds,
  "vmwNsxMLogserverEventGenStopped" : _vmwNsxMLogserverEventGenStopped_vbinds,
  "vmwNsxMApplicationRuleManagerFlowAnalysisStart" : _vmwNsxMApplicationRuleManagerFlowAnalysisStart_vbinds,
  "vmwNsxMApplicationRuleManagerFlowAnalysisFailed" : _vmwNsxMApplicationRuleManagerFlowAnalysisFailed_vbinds,
  "vmwNsxMApplicationRuleManagerFlowAnalysisComplete" : _vmwNsxMApplicationRuleManagerFlowAnalysisComplete_vbinds
}