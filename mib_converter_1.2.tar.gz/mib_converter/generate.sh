#!/usr/bin/env bash

node ./bin/ecgen.js $@

