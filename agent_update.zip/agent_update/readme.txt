The mib_converter has the ability to create a varbind conversion file if any of the vabinds have enumerated 
values.  The file is used for translating numerical values into their human-readable definitions.

Until this update is merged into the core product you can manually update your SNMP agent
as follows.

1) Back up and replace the following two files with the ones in this directory:

    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/manipulator/manipulator.py
    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/configurator/manipulator_config.py
    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/configurator/configurator.py

2) Update /etc/bigpanda/snmpd/snmpd-daemon.json


3) Restart the SNMP Agent:
    
    > sudo service bigpanda-snmpd restart
