#!/usr/bin/env bash

if ! [[ -x "$(command -v mibdump.py)" ]]; then
  echo 'Error: mibdump.py is not installed.' >&2
  exit 1
fi

if [ $# -eq 0 ]; then
    echo "Usage: convert.sh <filename>"
    exit 0
fi

while [[ $# -gt 0 ]]; do
  input_file="./$1"
  echo "Processing file: ${input_file}"
  mibdump.py --generate-mib-texts \
      --keep-texts-layout \
      --no-python-compile \
      --no-dependencies \
      --destination-format json \
      ${input_file} || exit 1
  echo ""
  shift
done

