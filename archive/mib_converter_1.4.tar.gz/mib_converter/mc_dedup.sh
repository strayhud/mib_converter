#!/usr/bin/env bash

#node ./bin/dedup.js $@
node /Users/hudson/dev/snmp-tools/mib_converter/bin/dedup.js $@
