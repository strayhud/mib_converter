readme.txt:

This is a very simple parser for reading a mib and converting it to our json structure.  It was developed for converting the included
ISILON-TRAP-MIB.mib file.  Parsing is currently very specific to this vendors mib format.   To use it on another vendors mib you will likely need
to make a few modifications.

To run it, simply provide the filename to convert on the command line as in:

node ./mib_convert.js <filename>

It will create an output file using the internal name of the MIB that it finds on this line:

    ISILON-TRAP-MIB DEFINITIONS ::= BEGIN
        
The file 'ISILON-TRAP-MIB.json' would be created in this case.

For the ISILON mib format it will take defintions like these:

nodeStatusCrit NOTIFICATION-TYPE
    OBJECTS     { nodeIdentifier, instanceIdentifier }
    STATUS      current
    DESCRIPTION
        "A critical node status event has occurred.
        "
    ::= { nodeStatus 3 }

nodeStatusInfo NOTIFICATION-TYPE
    OBJECTS     { nodeIdentifier, instanceIdentifier }
    STATUS      current
    DESCRIPTION
        "A node status event has occurred.
        "
    ::= { nodeStatus 7 }


And turn them into these:

  {
    "mib":"ISILON-TRAP-MIB",
    "trap":"nodeStatusCrit",
    "drop": [],
    "rename": {
      "nodeIdentifier":"nodeId",
      "instanceIdentifier":"instanceId"
    },
    "set": {
      "status":"critical",
      "check":"nodeStatus",
      "incident_identifier": "nodeStatus_{nodeId}_{instanceId}",
      "description":"A critical node status event has occurred."
    },
    "map-status": {},
    "set-time": true,
    "primary":"trap",
    "secondary":"instanceId"
  },
  {
    "mib":"ISILON-TRAP-MIB",
    "trap":"nodeStatusInfo",
    "drop": [],
    "rename": {
      "nodeIdentifier":"nodeId",
      "instanceIdentifier":"instanceId"
    },
    "set": {
      "status":"ok",
      "check":"nodeStatus",
      "incident_identifier": "nodeStatus_{nodeId}_{instanceId}",
      "description":"A node status event has occurred."
    },
    "map-status": {},
    "set-time": true,
    "primary":"trap",
    "secondary":"instanceId"
  }

