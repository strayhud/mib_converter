// Netcool Rule Conversion Utility
// run with:  node convert.js [input file] > [output file]

// DONE: add auto output file creation based on mib name
// DONE: only set secondary if instanceIdentifier exist in the attributes.
// DONE: remove duplicate attribute values in rename section.
// TODO: modify parsing to handle multi-line Object values

/* TODOs
1) put renames back, but create short name
 "nodeIdentifier" : "nodeId"
 
 2) add check name

*/



const DEBUG = 0;

const START = 0;
const LOOKING_FOR_NOTIFICATION = 1;
const LOOKING_FOR_OBJECTS = 2;
const LOOKING_FOR_STATUS = 3;
const LOOKING_FOR_DESCRIPTION = 4;
const LOOKING_FOR_END = 5;

var filename = null;
var mibname = "";
var trapname = "";
var check = "";
var state = START;
var target_status = "";
var description = "";
var firstalert = true;
var secondary_property = "";
var instanceIdFound = false;
var nodeIdFound = false;


var argv = process.argv.slice(1);
if (argv.length>1) {
    filename = argv[1];
}

if (filename==null) {
    console.log("Usage: node mib_convert.js <filename>");
    process.exit(1);
}

const fs = require('fs')
const readline = require('readline');

const inStream = readline.createInterface({
    input: fs.createReadStream(filename)
});

var outStream = null;  // wait until we've parsed the MIB name to create the output file.

// Line based state engine.   
inStream.on('line', function (line) {
    line = cleanLine(line);
    if (line) {
        debug(3,line);
        switch (state) {
        case START:
            if (!line.match(/^\s*#/))
                console.log(line);
            break;
        case LOOKING_FOR_NOTIFICATION:
            if (line.indexOf("NOTIFICATION-TYPE") !=-1) {
                parseTrapName(line);
                state = LOOKING_FOR_OBJECTS;
            } 
            break;
        case LOOKING_FOR_OBJECTS:
            if (line.indexOf("OBJECTS") !=-1) {
                startAlertDefinition(line);
                state = LOOKING_FOR_STATUS;
            } else {
                state = LOOKING_FOR_NOTIFICATION;
            }
            break;
        case LOOKING_FOR_STATUS:
            if (line.indexOf("STATUS") !=-1) {
                addAlertStatus(line);
                state = LOOKING_FOR_DESCRIPTION;
            }
            break;
        case LOOKING_FOR_DESCRIPTION:
            if (line.indexOf("DESCRIPTION") !=-1) {
                state = LOOKING_FOR_END;
            }
            break;
        case LOOKING_FOR_END:
            if (line.indexOf("::=") !=-1) {
                finalizeAlertDefinition(description);
                state = LOOKING_FOR_NOTIFICATION;
                description = "";
            } else {
                description = description+line.trim();
            }
            break;
        }
    }
});

// Finish the JSON structure and close the output stream 
inStream.on('close', function() {
  writeline("  }");
  writeline("]");
  if (outStream)
      outStream.end(); 
  //process.exit(0);
});


function cleanLine(line) {
    if (line.match(/^\s*#/))
        return null;
    let ndx = line.indexOf("#");
    if (ndx!=-1) 
        line = line.substring(0,ndx);
    return line;
}

// Parse the mibname and create the output file
function parseMIBName(line) {
    mibname = line.split(" ")[0];
    if (mibname && mibname.length>0)
        outStream = fs.createWriteStream(mibname+".json");
    writeline("[");
    debug(1,"mibname="+mibname);
}

// Parse the trapname.  Also closes off the previous alert definition if its not the first alert
function parseTrapName(line) {
    trapname = line.split(" ")[0];
    
    if (line.indexOf("Warn") !=-1) {
        target_status = "warning";
        check = trapname.substring(0, trapname.length-4);
    } else if (line.indexOf("Info") !=-1) {
        target_status = "ok";
        check = trapname.substring(0, trapname.length-4);
    } else if (line.indexOf("Crit") !=-1) {
        target_status = "critical";
        check = trapname.substring(0, trapname.length-4);
    } else if (line.indexOf("Emerg") !=-1) {
        target_status = "critical";
    } else {
        
    }
    
    if (!firstalert)
        writeline("  },");
    if (trapname!="")
        debug(1,"trapname="+trapname);
}
  
function startAlertDefinition(line) {
    
    writeline("  {");
    writeline('    "mib":"'+mibname+'",');
    writeline('    "trap":"'+trapname+'",');
    writeline('    "drop": [],');
    
    secondary_property = "";
    instanceIdFound = false;
    nodeIdFound = false;

    var str = line.match(/{\s+(.*)\s+}/);
    if (str && str.length>1) {
        var attrs = uniq(trimValues(str[1].split(",")));
        writeline('    "rename": {');
        attrs.forEach(function(value, idx, array){
            value = value.trim();
            if (idx < array.length - 1){ 
                writeline('      "'+value+'":"'+shortValue(value)+'",'); 
            } else {
                writeline('      "'+value+'":"'+shortValue(value)+'"');
            }
            
            // Set secondary_property if the value is 'instance_identifier', otherwise 
            // set it to the first identifier that it finds.   Note that the value 'instanceIdentifier'
            // will always override what ever the value is.
            if (value=="instanceIdentifier") {
                secondary_property = "instanceId";
                instanceIdFound = true;
            }
            else if (secondary_property=="" && value.indexOf("Identifier") !=-1) {
                secondary_property = "nodeId";
                nodeIdFound = true;
            }
        });
        writeline("    },");
        writeline('    "set": {'); 
    }
    firstalert = false;
}

function addAlertStatus(line) {
    // Hard coding for now.  Not sure if we can put some logic here to set it based on the trap status
    writeline('      "status":"'+target_status+'",');           
}

function finalizeAlertDefinition(description) {
    if (secondary_property == "")
        secondary_property = "strArg";

    writeline('      "check":"'+check+'",');    
    if (instanceIdFound && nodeIdFound)           
        writeline('      "incident_identifier": "'+check+'_{nodeId}_{instanceId}",'); 
    else 
        writeline('      "incident_identifier": "'+check+'_{'+secondary_property+'}",');           

    writeline('      "description":'+description);           
    writeline("    },");
    writeline('    "map-status": {},');
    writeline('    "set-time": true,');
    writeline('    "primary":"trap",');
    writeline('    "secondary":"'+secondary_property+'"');
}

//------- Utilitiy functions------------


function shortValue(str) {
    if (str.indexOf("Identifier") !=-1) {
        return str.replace(/Identifier/,'Id');
    } else if (str.indexOf("string") !=-1) {
        return str.replace(/string/,'str');
    } else if (str.indexOf("Message") !=-1) {
        return str.replace(/Message/,'Msg');
    } else if (str.indexOf("ValueStr") !=-1) {
        return str.replace(/ValueStr/,'Value');
    }

    // Otherwise add an underscore to the string to make it unique.
    return str+"_";
}

function uniq(a) {
    var seen = {};
    return a.filter(function(item) {
        return seen.hasOwnProperty(item) ? false : (seen[item] = true);
    });
}

function trimValues(a) {
    for (let key in a) {
      a[key] = a[key].trim();
    }
    return a;
}

function writeline(str) {
    if (outStream)
        outStream.write(str+'\n');
}

function debug(level,str) {
    if (level<=DEBUG)
        console.log(str);
}

function debugArray(str,a) {
    debug(2,str);
    a.forEach(function(value, idx, array) {
        debug(2,'"'+value+'"');
    });
}
