import os
import json
import logging

from pysnmp import debug
from bp_snmpd.configurator.exceptions import *
from logging.handlers import RotatingFileHandler
from bp_snmpd.configurator.security_config import SecurityConfig
from bp_snmpd.helpers.event_config import EventConfigHelper
from jsonschema import validate, ValidationError, SchemaError
from bp_snmpd.configurator.emitter_config import EmitterConfig
from bp_snmpd.configurator.consumer_config import ConsumerConfig
from bp_snmpd.configurator.translator_config import TranslatorConfig
from bp_snmpd.configurator.manipulator_config import ManipulatorConfig
from bp_snmpd.configurator.health_check_config import HealthCheckConfig
from bp_snmpd.configurator.configuration_file_schema import CONFIGURATION_FILE_SCHEMA


class Configurator(object):

    CONFIGURATION_BASE_PATH = "/etc/bigpanda/snmpd/"
    CONFIGURATION_FILE_NAME = "snmp-daemon.json"
    CONFIG_PATH_SEPARATOR = ' -> '

    DEFAULT_LOG_FILE_PATH = '/var/log/bigpanda/bigpanda-snmpd.log'
    DEFAULT_LOG_FORMAT = '%(asctime)s %(filename)s %(lineno)s %(process)d %(levelname)s: %(message)s'

    def __init__(self, config):
        self.config = config

        self._configure_modules()

    def get_logger(self):
        return self.logger

    def get_consumer_config(self):
        return self._consumer_config

    def get_translator_config(self):
        return self._translator_config

    def get_manipulator_config(self):
        return self._manipulator_config

    def get_emitter_config(self):
        return self._emitter_config

    def get_health_check_config(self):
        return self._health_check_config

    @staticmethod
    def configure(base_path=None, file_path=None):
        if base_path is not None:
            Configurator.CONFIGURATION_BASE_PATH = base_path

        if not file_path:
            file_path = os.path.join(Configurator.CONFIGURATION_BASE_PATH,
                                     Configurator.CONFIGURATION_FILE_NAME)

        return Configurator._from_file(file_path)

    @staticmethod
    def _from_file(file_path):
        try:
            with open(file_path, 'r') as _file:
                return Configurator._read_json_file(_file)
        except IOError:
            if not os.path.exists(file_path):
                raise ConfigurationFileNotFoundException("configuration file not found. path: {!s}".format(file_path))
            raise

    @staticmethod
    def _read_json_file(_file):
        try:
            config = json.load(_file)
            validate(config, CONFIGURATION_FILE_SCHEMA)
            return Configurator._from_dict(config)
        except ValueError:
            raise WrongConfigurationFileStructureException("can't read configuration file.")
        except (SchemaError, ValidationError) as ex:
            raise WrongConfigurationFileStructureException(ex.message)

    @staticmethod
    def _from_dict(config):
        return Configurator(config)

    def _configure_modules(self):
        try:
            self._configure_logging()
            self._configure_consumer()
            self._configure_event_configs()
            self._configure_translator()
            self._configure_manipulator()
            self._configure_emitter()
            self._configure_health_check()
        except (ConfigurationFileNotFoundException, MissingConfigurationException,
                WrongConfigurationFileStructureException, DuplicateTrapTypeException):
            raise

    def _configure_logging(self):
        log_format = self._get_config(['logging', 'log_format'])
        log_level = self._get_config(['logging', 'log_level'])
        log_dir = self._get_config(['logging', 'logs-dir'])

        log_filename = os.path.join(log_dir, 'bigpanda-snmpd.log')
        self._check_write_access(log_dir)
        try:
            verbose = self._get_config(['logging', 'verbose'])
            # turn on pysnmp debug logging
            if verbose:
                debug.setLogger(debug.Debug('all'))
        except MissingConfigurationException:
            pass

        logging.basicConfig(format=log_format, level=log_level)
        logger = logging.getLogger()

        file_handler = RotatingFileHandler(filename=log_filename, maxBytes=50*1024*1024, backupCount=10)
        file_handler.setFormatter(logging.Formatter(fmt=log_format))
        logger.addHandler(file_handler)

        self.logger = logging.getLogger(__name__)

    @staticmethod
    def remove_stdout_logging_handler():
        logger = logging.getLogger()
        stdout_handler = logger.handlers[0]
        logger.removeHandler(stdout_handler)

    def _configure_consumer(self):
        _ = self._get_config(['snmp', 'protocol'])
        _ = self._get_config(['snmp', 'port'])

        snmp_config = self._get_config(['snmp'])

        try:
            security_config = self._get_config(['security'])
            if security_config:
                security_config = SecurityConfig(**security_config)
        except MissingConfigurationException:
            security_config = None
        self._consumer_config = ConsumerConfig(security_config=security_config, **snmp_config)

    def _configure_translator(self):
        mibs_dir = self._get_config(['processing', 'mibs-dir'])

        try:
            capture_level = self._get_config(['logging', 'raw_capture_level'])
        except MissingConfigurationException:
            capture_level = 'ERROR'

        log_raw = self._get_config(['logging', 'raw'])
        log_translated = self._get_config(['logging', 'translated'])
        self._translator_config = TranslatorConfig(mibs_dir, self.event_configs, log_raw,
                                                   capture_level.upper(), log_translated)

    def _configure_manipulator(self):
        log_manipulated = self._get_config(['logging', 'manipulated'])

        try:
            alert_on_failure = self._get_config(['processing', 'alert_on_failure'])
        except MissingConfigurationException:
            alert_on_failure = True

        try:
            generate_event_configs = self._get_config(['processing', 'generate_event_configs'])
        except MissingConfigurationException:
            generate_event_configs = True

        #SRH-MOD
        try:
            convert_ip = self._get_config(['processing', 'convert_ip_to_hostname'])
        except MissingConfigurationException:
            convert_ip = False

        #SRH-MOD
        self._manipulator_config = ManipulatorConfig(log_manipulated, self.event_configs, alert_on_failure,
                                                     self.CONFIGURATION_BASE_PATH, generate_event_configs, convert_ip)

    def _configure_emitter(self):
        target_dir = self._get_config(['processing', 'target-dir'])
        log_dir = self._get_config(['logging', 'logs-dir'])
        log_format = self._get_config(['logging', 'log_format'])
        self._check_write_access(target_dir)

        try:
            stress_test = self._get_config(['processing', 'stress_test'])
        except MissingConfigurationException:
            stress_test = False

        self._emitter_config = EmitterConfig(target_dir, log_dir, log_format, stress_test)

    def _configure_health_check(self):
        try:
            port = self._get_config(['health_check', 'port'])
            file_name = self._get_config(['health_check', 'file_name'])

            log_dir = self._get_config(['logging', 'logs-dir'])
        except MissingConfigurationException:
            self.logger.debug("health check configuration is missing")
            self._health_check_config = None
            return

        self._health_check_config = HealthCheckConfig(port, log_dir, file_name)

    def _configure_event_configs(self):
        try:
            event_config_file_paths = self._get_config(['processing', 'event-configs'])
            self.event_configs = EventConfigHelper.load_event_configs(
                self.CONFIGURATION_BASE_PATH, event_config_file_paths)
        except (MissingConfigurationException, MissingConfigurationException, Exception) as ex:
            self.logger.error(ex.args)
            raise LoadEventConfigException

    def _get_config(self, config_path):
        config = None
        for ix, conf_name in enumerate(config_path):
            try:
                config = config[conf_name] if config else self.config[conf_name]
            except (KeyError, TypeError):
                config_path = config_path[:ix + 1]
                raise MissingConfigurationException("{!s} config is missing. config path: {!s}"
                                                    .format(conf_name, self.CONFIG_PATH_SEPARATOR.join(config_path)))

        return config

    @staticmethod
    def _check_write_access(path):
        if not os.path.exists(path):
            raise PathDoesNotExistException("{!s} does not exist.".format(path))

        if not os.access(path, os.W_OK):
            raise MissingWritePermissionException("{!s} has no write access".format(path))
