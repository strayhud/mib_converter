
mib_converter is a utility for generating BigPanda event configs from SNMP MIB files.  It allows 
you to create custom 'generators' for unique situations as all MIBs are not created equal.  It 
will also create a varbind conversion file if any of the vabinds have enumerated type values.  The
varbind conversion file is used for translating numerical values into their human-readable definitions.

The converter currently consists of two parts:

1) A customizable conversion utility for createing the event configs and varbind conversion files.
This is intended to be a tool for helping you create event configs from large MIBs.  In most (or 
most likely all) cases you need to run it several times customizing the logic between runs to 
generate a correct event config.  Custom 'generators' can be created with javascript class files. 
See the readme and example files in the ./bin directory for more info.

2) An update to the BigPanda SNMP Agent to do the actual varbind conversions.  Until it merged 
into the core product there are instructions on how to update the SNMP agent in 
./agent_update/readme.tx


TO GENERATE AN EVENT CONFIG:

1) Create a sub-directory under mib_converter and copy the mib files to it:

    mkdir /etc/bigpanda/snmpd/mib_converter/mibs/hp_nnmi
    cp *.txt /etc/bigpanda/snmpd/mib_converter/mibs/hp_nnmi

2) Run convert.sh to parse and generate a JSON form of the MIB:

    ./convert.sh mibs/hp_nnmi/hp-nnmi-nbi.txt

    Note: this only needs to be done once.

3) Run generate.sh on the json file:

    ./generate.sh mibs/hp_nnmi/HP-NNMI-NBI-MIB.json

    Note: this may need to be run several times with updated logic

4) Update the generated event config if/as needed

5) Copy the generated files to your SNMP server:

    cp mibs/hp_nnmi/HP-NNMI-NBI-MIB.py /etc/bigpanda/snmpd/lookup_files
    cp mibs/hp_nnmi/HP-NNMI-NBI-MIB.ec /etc/bigpanda/snmpd/event_configs

6) Add the event config to /etc/bigpanda/snmpd/snmp-daemon.json

7) Restart the snmp agent
