import os
import json

from bp_snmpd.configurator.exceptions import DuplicateTrapTypeException


class ManipulatorConfig(object):

    TEMPLATES_DIR_NAME = "event_configs"
    VARBIND_MAP_DIR_NAME = "varbind_maps"   #SRH - where the varbind maps live
    GENERATED_EVENT_CONFIGS_DIR_NAME = "auto-generated-event-configs"
    MIB_TEMPLATE_FILE_NAME = "mib_template.json"
    NO_MIB_TEMPLATE_FILE_NAME = "no_mib_template.json"

    def __init__(self, log_manipulated, event_configs, alert_on_failure, config_base_dir, generate_event_configs):
        self._log_manipulated = log_manipulated
        self._event_configs = event_configs
        self._alert_on_failure = alert_on_failure
        self._generate_event_configs = generate_event_configs

        self._config_base_dir = config_base_dir

        self._mib_event_config_template = self._read_template_file(self.MIB_TEMPLATE_FILE_NAME)
        self._no_mib_event_config_template = self._read_template_file(self.NO_MIB_TEMPLATE_FILE_NAME)

        self._map_event_config_to_trap_type()

    def get_event_configs(self):
        return self._event_configs

    def get_trap_mib_name_to_event_config(self):
        return self.trap_mib_name_to_event_config

    def should_log_manipulated(self):
        return self._log_manipulated

    def should_alert_on_failure(self):
        return self._alert_on_failure

    def should_generate_event_configs(self):
        return self._generate_event_configs

    def get_mib_event_config_template(self):
        return self._mib_event_config_template

    def get_no_mib_event_config_template(self):
        return self._no_mib_event_config_template

    def get_generated_event_configs_target_path(self, file_name):
        return os.path.join(self._config_base_dir, self.GENERATED_EVENT_CONFIGS_DIR_NAME, "{!s}.json".format(file_name))

    #SRH - added the following to get the varbind map directory
    def get_varbind_map_dir(self):
        return os.path.join(self._config_base_dir, self.VARBIND_MAP_DIR_NAME)

    @staticmethod
    def generate_event_config_key(mib_name, trap_name):
        return "{!s}-{!s}".format(mib_name, trap_name)

    def _map_event_config_to_trap_type(self):
        self.trap_mib_name_to_event_config = {}
        for event_config in self._event_configs:
            mib_name = event_config.get_mib_name()
            trap_name = event_config.get_trap_name()
            event_config_key = self.generate_event_config_key(mib_name, trap_name)

            if self.trap_mib_name_to_event_config.get(event_config_key):
                raise DuplicateTrapTypeException(u"found two event configs with the same mib and trap name."
                                                 u" mib name: {!s} trap name: {!s}".format(mib_name, trap_name))

            self.trap_mib_name_to_event_config[event_config_key] = event_config

    def _read_template_file(self, file_name):
        file_path = os.path.join(self._config_base_dir, self.TEMPLATES_DIR_NAME, file_name)
        with open(file_path, 'r') as _file:
            return json.loads(_file.read())
