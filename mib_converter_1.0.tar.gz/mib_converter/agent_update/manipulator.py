# coding=utf-8

import time
import logging
import sys # SRH-MOD

from bp_snmpd.emitter.emitter import Emitter
from bp_snmpd.models.event_config import EventConfig
from bp_snmpd.configurator.exceptions import NoSuchEventConfigException
from bp_snmpd.helpers.case_insensitive_dict import CaseInsensitiveDict
from bp_snmpd.manipulator.exceptions import InvalidStatusException, TemplateException, SuppressException


class Manipulator(object):

    MIB_FIELD_NAME = 'mib'
    TRAP_FIELD_NAME = 'trap'
    TIME_FIELD_NAME = 'timestamp'
    PRIMARY_FIELDS_NAME = 'primary_property'
    SECONDARY_FIELDS_NAME = 'secondary_property'
    STATUS_FIELD_NAME = 'status'
    OK_SEVERITY = 'ok'
    VALID_SEVERITIES = [OK_SEVERITY, 'unknown', 'warning', 'critical']

    SYSTEM_FIELD_PREFIX = 'snmp_'
    PROTOCOL_FIELD_NAME = 'protocol'
    PORT_FIELD_NAME = 'port'
    COMMUNITY_FIELD_NAME = 'community'
    VERSION_FIELD_NAME = 'trap_version'
    SOURCE_IP_FIELD_NAME = 'source_ip'
    SOURCE_PORT_FIELD_NAME = 'source_port'
    TRAP_NAME_FIELD_NAME = 'trap_name'
    TRAP_OID_FIELD_NAME = 'trap_oid'

    NESTED_TEMPLATE_DEPTH_LEVEL = 2

    DONT_STRINGIFY_KEY_LIST = ['timestamp']

    def __init__(self, configurator, emitter):
        self.logger = logging.getLogger(__name__)
        self._config = configurator.get_manipulator_config()
        self._consumer_config = configurator.get_consumer_config()

        self._emitter = emitter

        self.trap_mib_name_to_event_config = self._config.get_trap_mib_name_to_event_config()
        
        # SRH-MOD - this should be parameterized and not hard-coded
        sys.path.append(self._config.get_varbind_map_dir())

    def manipulate(self, trap_oid, trap_mib_name, trap_symbol_name, trap_payload,
                   trap_version, source, community, event_config=None):
        event_config_key = self._config.generate_event_config_key(trap_mib_name, trap_symbol_name)
        event_config = event_config or self.trap_mib_name_to_event_config.get(event_config_key)
        source_ip, source_port = source

        if not event_config:
            if self._config.should_alert_on_failure():
                self._emitter.emit_exception(trap_oid, source_ip, source_port)

            self.generate_event_config(trap_oid, trap_mib_name, trap_symbol_name)
            raise NoSuchEventConfigException(u"event config not found for trap mib name: {!s}, "
                                             u"trap_symbol_name: {!s}".format(trap_mib_name, trap_symbol_name))

        self.logger.debug(u"before: {!s}".format(trap_payload))
        trap_payload = CaseInsensitiveDict(trap_payload)

        if event_config.no_mib_support():
            trap_payload = self._map_order_to_var_bind(trap_payload, event_config.get_trap_var_binds())

        if event_config.should_add_system_fields():
            trap_payload = self._add_system(event_config, trap_payload, trap_version, source_ip, source_port, community)

        trap_payload = self._copy(trap_payload, event_config.get_fields_to_copy())
        trap_payload = self._rename(trap_payload, event_config.get_fields_to_rename())
        trap_payload = self._add(trap_payload, trap_mib_name, trap_symbol_name, event_config)
        trap_payload = self._set(trap_payload, event_config.get_fields_to_set())
        trap_payload = self._drop(trap_payload, event_config.get_fields_to_drop())

        trap_payload = self._conditions(trap_payload, event_config.get_conditions())

        # This line must be after _rename and _set functions
        trap_payload = self._convert_status(trap_payload, event_config.get_map_status())
        trap_payload = self._resolve_alarm(trap_payload, event_config.get_resolve_mapping())

        # SRH-MOD - Make the call to convert varbinds here
        trap_payload = self._convert_varbinds(trap_payload,event_config.get_trap_var_binds())
        
        log_manipulated = self.logger.info if self._config.should_log_manipulated() else self.logger.debug
        log_manipulated(u"manipulated: {!s}".format(trap_payload))

        trap_payload = self._stringify_trap_payload_values(trap_payload)
        self._emitter.emit(trap_payload)

        return trap_payload

    # SRH-MOD - this function dynamically loads the varbind conversion file for the specified 
    # mib and then loops through the data replacing any values that match
    def _convert_varbinds(self, trap_payload, var_binds):
        try:
            mib_name=trap_payload['mib_name']  # default tag 
            try:
                mib = __import__(mib_name)
                traps = getattr(mib, 'traps')
                if traps:
                    for varbind in var_binds.iteritems():
                        try:
                            val = traps[trap_payload['snmp_trap_name']][varbind[0]][trap_payload[varbind[0]]]
                            if val!=None:
                                trap_payload[varbind[0]]=val
                        except KeyError:
                            # quietly ignore if not found
                            pass
                else:
                    self.logger.debug(u"No traps found in varbind conversion file: {!s}".format(mib_name))
            except ImportError:
                self.logger.debug(u"Failed to load varbind conversion file: {!s}".format(mib_name))
        except KeyError:
            # quietly ignore if there is no mib_name
            pass
        return trap_payload

    def generate_event_config(self, trap_oid, trap_mib_name=None, trap_symbol_name=None, trap_var_binds=None):
        if not self._config.should_generate_event_configs():
            return

        is_mib_event_config = None not in [trap_mib_name, trap_symbol_name]
        if is_mib_event_config:
            template = self._config.get_mib_event_config_template()
            template['mib'] = trap_mib_name
            template['trap'] = trap_symbol_name
        else:
            template = self._config.get_no_mib_event_config_template()
            template['trap'] = str(trap_oid)
            template['trap-oid'] = str(trap_oid)
            template['trap-var-binds'] = trap_var_binds or {}

        event_configs = [template]
        event_config = EventConfig.from_dict(template)
        file_path = self._config.get_generated_event_configs_target_path(trap_oid)
        self._emitter.save_event_configs_if_needed(file_path, event_configs)
        self.logger.info(u"event config generated for trap oid: {!s}".format(trap_oid))
        return event_config

    def _map_order_to_var_bind(self, trap_payload, var_binds):
        order_to_symbol_name = {str(order): symbol_name for symbol_name, order in var_binds.iteritems()}
        return self._rename(trap_payload, order_to_symbol_name)

    def _drop(self, trap_payload, fields_to_drop):
        for field in fields_to_drop:
            try:
                del trap_payload[field]
            except KeyError:
                self.logger.debug(u"drop field: {!s} does not exist in trap payload".format(field))

        return trap_payload

    def _rename(self, trap_payload, fields_to_rename):
        for field, to in fields_to_rename.iteritems():
            try:
                trap_payload[to] = trap_payload[field]
                del trap_payload[field]
            except KeyError:
                self.logger.debug(u"rename field: {!s} does not exist in trap payload".format(field))

        return trap_payload

    def _set(self, trap_payload, fields_to_set, depth=1):
        is_last_loop = depth == self.NESTED_TEMPLATE_DEPTH_LEVEL
        for field, val in fields_to_set.iteritems():
            try:
                old_value = trap_payload[field]
                if old_value and depth == 1:
                    self.logger.debug(u"set field: {!s} does exist in trap payload. "
                                      u"old value: {!s} new value: {!s}".format(field, old_value, val))
            except KeyError:
                pass
            finally:
                val = self._template_value(field, val, trap_payload, is_last_loop=is_last_loop)
                trap_payload[field] = val

        if is_last_loop:
            return trap_payload

        depth += 1
        return self._set(trap_payload, fields_to_set, depth=depth)

    def _add(self, trap_payload, trap_mib_name, trap_symbol_name, event_config):
        additional_fields = {self.MIB_FIELD_NAME: trap_mib_name,
                             self.TRAP_FIELD_NAME: trap_symbol_name}

        if event_config.should_set_time():
            now = int(time.time())
            additional_fields[self.TIME_FIELD_NAME] = now
            self.logger.debug(u"added time field. {!s}: {!s}"
                              .format(self.TIME_FIELD_NAME, now))

        primary = event_config.get_primary()
        if primary is not None:
            additional_fields[self.PRIMARY_FIELDS_NAME] = primary
            self.logger.debug(u"added primary field. {!s}: {!s}"
                              .format(self.PRIMARY_FIELDS_NAME, primary))

        secondary = event_config.get_secondary()
        if secondary is not None:
            additional_fields[self.SECONDARY_FIELDS_NAME] = secondary
            self.logger.debug(u"added secondary field. {!s}: {!s}"
                              .format(self.SECONDARY_FIELDS_NAME, secondary))

        return self._set(trap_payload, additional_fields)

    def _copy(self, trap_payload, fields_to_copy):
        for _from, to in fields_to_copy.iteritems():
            try:
                trap_payload[to] = trap_payload[_from]
            except KeyError:
                self.logger.debug(u"failed to copy field from: {!s} to: {!s}".format(_from, to))

        return trap_payload

    def _add_system(self, event_config, trap_payload, trap_version, source_ip, source_port, community):
        def _add_prefixed_field(name, val):
            additional_fields[self.SYSTEM_FIELD_PREFIX + name] = val

        additional_fields = {}
        _add_prefixed_field(self.PROTOCOL_FIELD_NAME, self._consumer_config.get_protocol())
        _add_prefixed_field(self.PORT_FIELD_NAME, self._consumer_config.get_port())
        _add_prefixed_field(self.COMMUNITY_FIELD_NAME, community)
        _add_prefixed_field(self.VERSION_FIELD_NAME, trap_version)
        _add_prefixed_field(self.SOURCE_IP_FIELD_NAME, source_ip)
        _add_prefixed_field(self.SOURCE_PORT_FIELD_NAME, source_port)

        trap_name = event_config.get_trap_name()
        if trap_name:
            _add_prefixed_field(self.TRAP_NAME_FIELD_NAME, trap_name)

        trap_oid = event_config.get_trap_oid()
        if trap_oid:
            _add_prefixed_field(self.TRAP_OID_FIELD_NAME, trap_oid)

        return self._set(trap_payload, additional_fields)

    def _convert_status(self, trap_payload, map_status):
        try:
            current_status = trap_payload[self.STATUS_FIELD_NAME]
            if type(current_status) != unicode:
                current_status = str(trap_payload[self.STATUS_FIELD_NAME])
            map_status = CaseInsensitiveDict(map_status)
            if current_status in map_status:
                trap_payload[self.STATUS_FIELD_NAME] = map_status[current_status]
        except KeyError:
            self.logger.info(u"status fields not found in trap payload")
        finally:
            return self._validate_status_field(trap_payload)

    def _validate_status_field(self, trap_payload):
        if trap_payload.get(self.STATUS_FIELD_NAME) is None or\
                        trap_payload[self.STATUS_FIELD_NAME] not in self.VALID_SEVERITIES:
            raise InvalidStatusException(u"invalid status: {!s}. valid statuses: {!s}"
                                         .format(trap_payload.get(self.STATUS_FIELD_NAME), self.VALID_SEVERITIES))

        return trap_payload

    def _resolve_alarm(self, trap_payload, resolve_mapping):
        for key, val in resolve_mapping.iteritems():
            if trap_payload.get(key) == val:
                trap_payload[self.STATUS_FIELD_NAME] = self.OK_SEVERITY
                break

        return trap_payload

    def _conditions(self, trap_payload, conditions):
        for condition in conditions:
            match = condition.test(trap_payload)
            if not match:
                continue

            action = condition.get_action()
            if action.is_suppress():
                raise SuppressException(u"got suppress action. condition name: {!s}".format(condition.get_name()))
            elif action.is_set():
                tags = condition.get_tags(trap_payload)
                try:
                    templated_parameters = action.get_parameters(tags)
                    trap_payload = self._set(trap_payload, templated_parameters)
                except KeyError:
                    raise TemplateException(u"failed to format value template.")

            break

        return trap_payload

    @staticmethod
    def _template_value(field, val, trap_payload, is_last_loop=False):
        try:
            return val.encode(Emitter.ENCODING).format(**trap_payload)
        except KeyError:
            if is_last_loop:
                raise TemplateException(u"failed to format value template. field: {!s}, "
                                        u"template: {!s}, trap payload: {!s}".format(field, val, trap_payload))
        except AttributeError:
            return val
        except UnicodeDecodeError:
            raise TemplateException("failed to format value template due to unicode error. field: {!s}, "
                                    "template: {!s}, trap payload: {!s}".format(field, val, trap_payload))

    def _stringify_trap_payload_values(self, trap_payload):
        for key, val in trap_payload.iteritems():
            if type(val) != unicode and key not in self.DONT_STRINGIFY_KEY_LIST:
                trap_payload[key] = str(val)

        return trap_payload
