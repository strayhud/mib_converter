Until this update is merged into the core product you can manually update your SNMP agent
as follows.

Replace the following two files with the same ones in this distro:

    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/manipulator/manipulator.py
    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/configurator/manipulator_config.py

1) untar mib_converter.tar in the /etc/bigpanda/snmpd directory.

2) You should see a directory structure smilar to the following:

    drwxr-xr-x. 2 root root  26 Jan  1 03:41 bin
    lrwxrwxrwx. 1 root root  19 Jan  1 02:36 convert.sh
    lrwxrwxrwx. 1 root root  20 Jan  1 03:46 generate.sh
    drwxr-xr-x. 2 root root 223 Jan  1 04:25 hp_nnmi
    drwxr-xr-x. 2 root root  55 Dec 31 23:21 ISILON
    drwxr-xr-x. 2 root root 148 Jan  1 03:55 out_files

    Note: the last 3 (maybe more) are example mib conversions and may or may not be included

3) Copy bin/manipulator.py to your SNMP agent dir:

    cp bin/manipulator.py /opt/bigpanda/bigpanda-snmpd/bp_snmpd/manipulator/manipulator.py

    Note: you may want to backup your manipulator.py before copying over it for safe keeping.

4) Restart the SNMP Agent:

    sudo service bigpanda-snmpd restart
