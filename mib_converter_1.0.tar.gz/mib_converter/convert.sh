#!/usr/bin/env bash

function usage {
    echo "Usage: ./convert.sh <mib file to convert> [-o <output directory>]"
    exit 0
}

while [[ $# -gt 0 ]]
do
KEY="$1"
#echo $KEY
case ${KEY} in
    -h|--help)
    usage
    shift # Past argument
    shift # Past value
    ;;
    -o|--output-directory)
    export OUTPUT_DIRECTORY="$2"
    shift
    shift
    ;;
    -i|--input-file)
    export MIB_FILE="$2"
    shift
    shift
    ;;
    *) # Unknown option
    export MIB_FILE=$1
    shift # Past argument
    ;;
esac
done

if ! [[ -x "$(command -v mibdump.py)" ]]; then
  echo 'Error: mibdump.py is not installed.' >&2
  exit 1
fi

if ! [[ -a $MIB_FILE ]]; then
  usage
fi

INPUT_DIRECTORY=$(dirname ${MIB_FILE})
if ! [[ -d $OUTPUT_DIRECTORY ]]; then
  export OUTPUT_DIRECTORY=$INPUT_DIRECTORY
fi

function compile {
    input_file=$1
    output_directory=$2
    echo "Source file: ${input_file}"
    mibdump.py --destination-directory=${output_directory} \
        --generate-mib-texts \
        --keep-texts-layout \
        --no-python-compile \
        --no-dependencies \
        --destination-format json \
        ${input_file} || exit 1
    echo ""
}


echo "MIB File: ${MIB_FILE}"
echo "Input directory: ${INPUT_DIRECTORY}"
echo "Output directory: ${OUTPUT_DIRECTORY}"
for file in `ls ${INPUT_DIRECTORY}/*.txt`; do
   # echo "Processing: ${file}"
   compile ${file} ${OUTPUT_DIRECTORY}
done

echo "Finished"