
mib_converter - A customizable SNMP conversion utility to help in creating BigPanda event config files.

BACKGROUND/OVERVIEW:

mib_converter is a utility for helping generate BigPanda event configs from SNMP MIB files.  The key
word is "helping" as its not a one-shot conversion tool that does it all.  Its purpose is to help you
convert large mibs and in most cases will require some programming expertise.  Specifically with
javascript.   There are several examples so hopefully it won't be too burdensome.  

The reason the utility is not a one-shot conversion tool is the SNMP standard gives vendors a lot of leeway 
in how they format their mibs, how they construct their traps, what values they use for event identiy purposes
and so forth.

There are two primary tasks that need to be performed when converting a MIB:

1) Properly identifying a trap to set the primary/secondary properties for the BP alert.  The trap name 
typically serves as the secondary property as it tells you what kind of event it is, but this may vary 
if there is additional identifying info in the var binds.   The bigger issue is knowing what device, host,
app, etc. is having the issue which is needed for setting the primary property.  Its common for vendors to 
rely on the IP address for specifying the "thing" having the issue, but this is not always helpful for humans
and there is currently no way to convert the IP address to an actual host name in the SNMP agent.  Often a
vendor will identify whats having the issue in a var bind, but its there is no standard.  This requires you
to inspect the incoming data and possibly send some test traps to find out if they are, and then update a
config for the conversion tool to use the specific var bind. 

2) Identifying the status of the trap (or alert). This is not always possible as many vendors do not send
anything indicating up or down, or at a minium its not consistent.  The status could be relayed in a var
bind or it could be embedded in the trap name such as in "ipNodeDown" or "ipNodeUp" which would 
need to be converted to "criticl" and "ok" respectively.  And vendors are free to use any naming convention 
they want (appending or prepending to the name) such as "Failed", "Warning", "OffLine", "OnLine", "Ok", etc. 
As a result it may take some hand editing of the generated event config if there is not a standard way to
identify the status. The generator will use a status of "critical" by default for all traps.   This ensures
you won't miss a trap but it prevents any auto-closing of alerts if the vendor sends such events.

3) There are a few other things that you may want to convert for each trap such as renaming varbinds, cleaning
up or building a better description of the alert, etc.    

HOW IT WORKS:

The mib_converter uses two utilities to do the conversion.  One is an open source python program called
"mibdump.py" and the other is a generator written in javascript called "ecgen.js".   The mibdump utility 
is used for converting the MIB file to a JSON format that the ecgen utility uses to generate the actual 
event config.

The mibdump utility only needs to be run once to create the JSON file as it should not change.  Any adjustments 
or tuning of the generated event config will be done with ecgen.  ecgen uses 'generators' for doing the 
conversions which can be created uniquely for each type of MIB.  There is a default generator that can be
tried first and then cloned and modified if needed.

There are a couple of other utilties that can help with the overall conversion process named dedup.js and
list.js.  Dedup helps identify any duplicate trap names across a set of event configs. The BigPanda 
agent will fail to start if there are any duplicate trap names and can be frustrating finding
them all after converting a batch of mibs.   The list.js utility can be helpful inspecting all of the 
generated values for certain tags (status, oid, primary, secondary) in a batch of event configs.   Such as 
showing all of the generated status values for each trapname to verify the values look reasonable.   

See the file named "how-to-use.txt" for informtion on how to convert a MIB.