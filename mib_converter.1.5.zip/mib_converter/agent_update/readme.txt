The mib_converter has the ability to create a varbind conversion file if any of the vabinds 
have enumerated values.  The file is used for translating numerical values into their 
human-readable definitions.

*** Until this update is merged into the core product you can manually update your SNMP agent
as follows.

*** Be sure and install the correct files.  This should be the V3 directory if you are using
the latest release of the BigPanda SNMP Agent and is compatible with Python 3.x.   The V2 
directory is provided for backward compatibility with the previous version of the agent that
only support Python 2.

1) Back up and replace the following two files with the ones in this directory:

    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/manipulator/manipulator.py
    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/configurator/manipulator_config.py
    /opt/bigpanda/bigpanda-snmpd/bp_snmpd/configurator/configurator.py

2) Update /etc/bigpanda/snmpd/snmpd-daemon.json

    - Add a flag to enable/disable source_ip translation if desired:

    "convert_ip_to_hostname": true

    - Add a value that specifies the location of the varbind map directory if desired:

    "varbind_maps" : "/etc/bigpanda/snmpd/varbind_maps"


3) Restart the SNMP Agent:
    
    > sudo service bigpanda-snmpd restart
