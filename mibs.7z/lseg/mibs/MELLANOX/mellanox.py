_PhysicalClass_type = {
  "1": "other",
  "2": "unknown",
  "3": "chassis",
  "4": "backplane",
  "5": "container",
  "6": "powerSupply",
  "7": "fan",
  "8": "sensor",
  "9": "module",
  "10": "port",
  "11": "stack",
  "12": "cpu"
}
_ProtocolStateType_type = {
  "1": "enabled",
  "2": "disabled"
}
_ModuleStateType_type = {
  "1": "ok",
  "2": "disabled",
  "3": "reset",
  "4": "missing",
  "5": "criticalFault",
  "6": "nonCriticalFault",
  "7": "unknown"
}
_EventCategory_type = {
  "0": "unknown",
  "1": "hardware",
  "2": "traffic",
  "3": "trafficConfiguration",
  "4": "trafficNotification",
  "5": "tabricTopology",
  "6": "tabricConfiguration",
  "7": "tabricNotification",
  "8": "communicationError",
  "9": "moduleStatus",
  "10": "environmentNotification",
  "11": "uFMServer",
  "12": "maintenance",
  "13": "logicalModel",
  "14": "gateway"
}
_EventSeverity_type = {
  "1": "cleared",
  "2": "indeterminate",
  "3": "critical",
  "4": "major",
  "5": "minor",
  "6": "warning"
}

_mellanoxETSModuleStateTrap_vbinds = {
  "mellanoxETSProtocolState" : _ProtocolStateType_type
}
_mellanoxETSPortAdminStateTrap_vbinds = {
  "mellanoxDCBPortETSAdminState" : _ProtocolStateType_type
}
_mellanoxETSPortOperStateTrap_vbinds = {
  "mellanoxDCBPortETSOperState" : _ProtocolStateType_type
}
_mellanoxETSPortPeerStateTrap_vbinds = {
  "mellanoxDCBPortETSPeerState" : _ProtocolStateType_type
}
_mellanoxPFCModuleStateTrap_vbinds = {
  "mellanoxPFCProtocolState" : _ProtocolStateType_type
}
_mellanoxPFCPortAdminStateTrap_vbinds = {
  "mellanoxDCBPortPFCAdminState" : _ProtocolStateType_type
}
_mellanoxPFCPortOperStateTrap_vbinds = {
  "mellanoxDCBPortPFCOperState" : _ProtocolStateType_type
}
_mellanoxPFCPortPeerStateTrap_vbinds = {
  "mellanoxDCBPortPFCPeerState" : _ProtocolStateType_type
}
_mellanoxEntStateChangeAlarm_vbinds = {
  "mellanoxEntStateModuleCurrentState" : _ModuleStateType_type,
  "mellanoxEntStateModulePreviousState" : _ModuleStateType_type
}
_ufmGIDAddressInService_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGIDAddressOutofService_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNewMCastGroupCreated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMCastGroupDeleted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSymbolError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLinkErrorRecovery_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLinkDowned_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortReceiveErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortReceiveRemotePhysicalErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortReceiveSwitchRelayErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortXmitDiscards_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortXmitConstraintErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortReceiveConstraintErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLocalLinkIntegrityErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmExcessiveBufferOverrunErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVL15Dropped_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCongestedBandwidthThresholdReached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortBandwidthThresholdReached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNon_optimallinkwidth_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortNormalizedTransmitWait_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmT4PortCongestedBandwidth_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmT4PortNormalizedTransmitWait_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFlowControlUpdateWatchdogTimerExpired_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCapabilityMaskModified_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSystemImageGUIDchanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLinkSpeedEnforcementDisabled_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLicenseexpired_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDuplicatedlicenses_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLicenseLimitExceeded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLicenseExpirationDate_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmBadM_Key_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmBadP_Key_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmBadQ_Key_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmBadP_KeySwitchExternalPort_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmISBLLAGPortUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmISBLLAGPortDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLAGPortUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLAGPortDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortofLAGUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortofLAGDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortofISBLUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortofISBLDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerStateChanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerStateChangeFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerResourcesAllocated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmComputeResourceReleased_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmComputeResourceAllocated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerAdditionalResourcesAllocated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerResourcesReleased_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerComputeResourceisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogicalServerComputeResourceisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLinkisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLinkisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNodeisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNodeisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortActionSucceeded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmPortActionFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceActionSucceeded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceActionFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNetworkInterfaceAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNetworkInterfaceRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmEnvironmentAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmEnvironmentRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNetworkAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNetworkRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMMbadaccesscredentials_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMCreated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMMisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMMisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMstatechanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMmigrationfailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMhasbeenmigrated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVMalarmstatushaschanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGatewayEthernetLinkStateChanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGatewayRe_registerEventReceived_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNumberofGatewaysisChanged_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGatewaywillbeRebooted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGatewayReloadingFinished_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVcenterisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmVcenterbadaccesscredentials_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchUpgradeError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmHostUpgradeFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchFWUpgradeStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchSWUpgradeStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchUpgradeFinished_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmHostFWUpgradeStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmHostSWUpgradeStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModulestatusNOTPRESENT_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchModuleRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModuleTemperatureThresholdReached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchModuleAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModulestatusFAULT_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceActionStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSiteActionStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSiteActionFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchChipAdded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchChipRemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDevicePendingReboot_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSystemInformationismissing_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchIdentityValidationFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceUpgradeFinished_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMBackUpStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMBackUpFinished_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMBackUpFinishedWithError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCoreDumpCreated_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMUP_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMFailover_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMSystemLogMessage_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMLIDChange_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricHealthReportInfo_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricHealthReportWarning_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricHealthReportError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFM_relatedprocessisdown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLogspurgefailure_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmRestartofUFM_relatedprocesssucceeded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMisbeingstopped_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMisbeingrestarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMfailoverisbeingattempted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMcannotconnecttoDB_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDiskutilizationthresholdreached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMemoryutilizationthresholdreached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCPUutilizationthresholdreached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricinterfaceisdown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMstandbyserverproblem_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMisdown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSMisnotresponding_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDRBDBadCondition_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmRemoteUFM_SMSync_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmRemoteUFM_SMproblem_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMHPurgeFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMHealthWatchdogInfo_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMHealthWatchdogCritical_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmTimeDiffBetweenHAServers_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDRBDTCPConnectionPerformance_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDailyReportCompletedsuccessfully_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDailyReportCompletedwithError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDailyReportFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDailyReportMailSentsuccessfully_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDailyReportMailSentFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGeneralExternalEventNotification_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGeneralExternalEventNotice_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGeneralExternalEventAlert_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmGeneralExternalEventError_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUserConnected_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUserDisconnected_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUFMServerFailover_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmEventsSuppression_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmReportSucceeded_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmReportFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCorrectionAttemptsPaused_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryEnabled_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryDisabled_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryBadConnection_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryConnectionEstablished_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryInconsistentVersion_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedsavemetadata_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedupdatemetadata_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedsavedata_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedgetmetadata_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedgetdata_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryFailedremovefile_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryversionnotmatchesUFMversion_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryPurgeDBOccurred_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryMigrationisnotcompleted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistorypartitionutilizationthresholdreached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistorylocalreportfilesareabouttobecleaned_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistoryoldestDBtableisabouttoberemoved_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMonitoringHistorypartitionisnotmounted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmNon_optimalLinkSpeed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUnhealthyIBPort_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricCollectorConnected_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricCollectorDisconnected_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmHighdataretransmissioncountonport_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDropEvents_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCRCAlignErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmUndersizePkts_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmOversizePkts_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFragments_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmJabbers_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCollisions_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmAlignmentErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFCSErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSingleCollisionFrames_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmMultipleCollisionFrames_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSQETestErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeferredTransmissions_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmLateCollisions_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmExcessiveCollisions_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmInternalMacTransmitErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmInternalMacReceiveErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmCarrierSenseErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFrameTooLongs_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSymbolErrors_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricConfigurationStarted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricConfigurationCompleted_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmFabricConfigurationFailed_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceConfigurationFailure_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDeviceConfigurationTimeout_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmProvisioningValidationFailure_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmSwitchisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDirectorSwitchisDown_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmDirectorSwitchisUp_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModuleTemperatureLowThresholdReached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModuleTemperatureHighThresholdReached_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModuleHighVoltage_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}
_ufmModuleHighCurrent_vbinds = {
  "severity" : _EventSeverity_type,
  "category" : _EventCategory_type
}

traps = {
  "mellanoxETSModuleStateTrap" : _mellanoxETSModuleStateTrap_vbinds,
  "mellanoxETSPortAdminStateTrap" : _mellanoxETSPortAdminStateTrap_vbinds,
  "mellanoxETSPortOperStateTrap" : _mellanoxETSPortOperStateTrap_vbinds,
  "mellanoxETSPortPeerStateTrap" : _mellanoxETSPortPeerStateTrap_vbinds,
  "mellanoxPFCModuleStateTrap" : _mellanoxPFCModuleStateTrap_vbinds,
  "mellanoxPFCPortAdminStateTrap" : _mellanoxPFCPortAdminStateTrap_vbinds,
  "mellanoxPFCPortOperStateTrap" : _mellanoxPFCPortOperStateTrap_vbinds,
  "mellanoxPFCPortPeerStateTrap" : _mellanoxPFCPortPeerStateTrap_vbinds,
  "mellanoxEntStateChangeAlarm" : _mellanoxEntStateChangeAlarm_vbinds,
  "ufmGIDAddressInService" : _ufmGIDAddressInService_vbinds,
  "ufmGIDAddressOutofService" : _ufmGIDAddressOutofService_vbinds,
  "ufmNewMCastGroupCreated" : _ufmNewMCastGroupCreated_vbinds,
  "ufmMCastGroupDeleted" : _ufmMCastGroupDeleted_vbinds,
  "ufmSymbolError" : _ufmSymbolError_vbinds,
  "ufmLinkErrorRecovery" : _ufmLinkErrorRecovery_vbinds,
  "ufmLinkDowned" : _ufmLinkDowned_vbinds,
  "ufmPortReceiveErrors" : _ufmPortReceiveErrors_vbinds,
  "ufmPortReceiveRemotePhysicalErrors" : _ufmPortReceiveRemotePhysicalErrors_vbinds,
  "ufmPortReceiveSwitchRelayErrors" : _ufmPortReceiveSwitchRelayErrors_vbinds,
  "ufmPortXmitDiscards" : _ufmPortXmitDiscards_vbinds,
  "ufmPortXmitConstraintErrors" : _ufmPortXmitConstraintErrors_vbinds,
  "ufmPortReceiveConstraintErrors" : _ufmPortReceiveConstraintErrors_vbinds,
  "ufmLocalLinkIntegrityErrors" : _ufmLocalLinkIntegrityErrors_vbinds,
  "ufmExcessiveBufferOverrunErrors" : _ufmExcessiveBufferOverrunErrors_vbinds,
  "ufmVL15Dropped" : _ufmVL15Dropped_vbinds,
  "ufmCongestedBandwidthThresholdReached" : _ufmCongestedBandwidthThresholdReached_vbinds,
  "ufmPortBandwidthThresholdReached" : _ufmPortBandwidthThresholdReached_vbinds,
  "ufmNon_optimallinkwidth" : _ufmNon_optimallinkwidth_vbinds,
  "ufmPortNormalizedTransmitWait" : _ufmPortNormalizedTransmitWait_vbinds,
  "ufmT4PortCongestedBandwidth" : _ufmT4PortCongestedBandwidth_vbinds,
  "ufmT4PortNormalizedTransmitWait" : _ufmT4PortNormalizedTransmitWait_vbinds,
  "ufmFlowControlUpdateWatchdogTimerExpired" : _ufmFlowControlUpdateWatchdogTimerExpired_vbinds,
  "ufmCapabilityMaskModified" : _ufmCapabilityMaskModified_vbinds,
  "ufmSystemImageGUIDchanged" : _ufmSystemImageGUIDchanged_vbinds,
  "ufmLinkSpeedEnforcementDisabled" : _ufmLinkSpeedEnforcementDisabled_vbinds,
  "ufmLicenseexpired" : _ufmLicenseexpired_vbinds,
  "ufmDuplicatedlicenses" : _ufmDuplicatedlicenses_vbinds,
  "ufmLicenseLimitExceeded" : _ufmLicenseLimitExceeded_vbinds,
  "ufmLicenseExpirationDate" : _ufmLicenseExpirationDate_vbinds,
  "ufmBadM_Key" : _ufmBadM_Key_vbinds,
  "ufmBadP_Key" : _ufmBadP_Key_vbinds,
  "ufmBadQ_Key" : _ufmBadQ_Key_vbinds,
  "ufmBadP_KeySwitchExternalPort" : _ufmBadP_KeySwitchExternalPort_vbinds,
  "ufmISBLLAGPortUp" : _ufmISBLLAGPortUp_vbinds,
  "ufmISBLLAGPortDown" : _ufmISBLLAGPortDown_vbinds,
  "ufmLAGPortUp" : _ufmLAGPortUp_vbinds,
  "ufmLAGPortDown" : _ufmLAGPortDown_vbinds,
  "ufmPortUp" : _ufmPortUp_vbinds,
  "ufmPortDown" : _ufmPortDown_vbinds,
  "ufmPortofLAGUp" : _ufmPortofLAGUp_vbinds,
  "ufmPortofLAGDown" : _ufmPortofLAGDown_vbinds,
  "ufmPortofISBLUp" : _ufmPortofISBLUp_vbinds,
  "ufmPortofISBLDown" : _ufmPortofISBLDown_vbinds,
  "ufmLogicalServerStateChanged" : _ufmLogicalServerStateChanged_vbinds,
  "ufmLogicalServerStateChangeFailed" : _ufmLogicalServerStateChangeFailed_vbinds,
  "ufmLogicalServerAdded" : _ufmLogicalServerAdded_vbinds,
  "ufmLogicalServerRemoved" : _ufmLogicalServerRemoved_vbinds,
  "ufmLogicalServerResourcesAllocated" : _ufmLogicalServerResourcesAllocated_vbinds,
  "ufmComputeResourceReleased" : _ufmComputeResourceReleased_vbinds,
  "ufmComputeResourceAllocated" : _ufmComputeResourceAllocated_vbinds,
  "ufmLogicalServerAdditionalResourcesAllocated" : _ufmLogicalServerAdditionalResourcesAllocated_vbinds,
  "ufmLogicalServerResourcesReleased" : _ufmLogicalServerResourcesReleased_vbinds,
  "ufmLogicalServerComputeResourceisDown" : _ufmLogicalServerComputeResourceisDown_vbinds,
  "ufmLogicalServerComputeResourceisUp" : _ufmLogicalServerComputeResourceisUp_vbinds,
  "ufmLinkisUp" : _ufmLinkisUp_vbinds,
  "ufmLinkisDown" : _ufmLinkisDown_vbinds,
  "ufmNodeisDown" : _ufmNodeisDown_vbinds,
  "ufmNodeisUp" : _ufmNodeisUp_vbinds,
  "ufmPortActionSucceeded" : _ufmPortActionSucceeded_vbinds,
  "ufmPortActionFailed" : _ufmPortActionFailed_vbinds,
  "ufmDeviceActionSucceeded" : _ufmDeviceActionSucceeded_vbinds,
  "ufmDeviceActionFailed" : _ufmDeviceActionFailed_vbinds,
  "ufmNetworkInterfaceAdded" : _ufmNetworkInterfaceAdded_vbinds,
  "ufmNetworkInterfaceRemoved" : _ufmNetworkInterfaceRemoved_vbinds,
  "ufmEnvironmentAdded" : _ufmEnvironmentAdded_vbinds,
  "ufmEnvironmentRemoved" : _ufmEnvironmentRemoved_vbinds,
  "ufmNetworkAdded" : _ufmNetworkAdded_vbinds,
  "ufmNetworkRemoved" : _ufmNetworkRemoved_vbinds,
  "ufmVMMbadaccesscredentials" : _ufmVMMbadaccesscredentials_vbinds,
  "ufmVMCreated" : _ufmVMCreated_vbinds,
  "ufmVMRemoved" : _ufmVMRemoved_vbinds,
  "ufmVMMisDown" : _ufmVMMisDown_vbinds,
  "ufmVMMisUp" : _ufmVMMisUp_vbinds,
  "ufmVMstatechanged" : _ufmVMstatechanged_vbinds,
  "ufmVMisDown" : _ufmVMisDown_vbinds,
  "ufmVMisUp" : _ufmVMisUp_vbinds,
  "ufmVMmigrationfailed" : _ufmVMmigrationfailed_vbinds,
  "ufmVMhasbeenmigrated" : _ufmVMhasbeenmigrated_vbinds,
  "ufmVMalarmstatushaschanged" : _ufmVMalarmstatushaschanged_vbinds,
  "ufmGatewayEthernetLinkStateChanged" : _ufmGatewayEthernetLinkStateChanged_vbinds,
  "ufmGatewayRe_registerEventReceived" : _ufmGatewayRe_registerEventReceived_vbinds,
  "ufmNumberofGatewaysisChanged" : _ufmNumberofGatewaysisChanged_vbinds,
  "ufmGatewaywillbeRebooted" : _ufmGatewaywillbeRebooted_vbinds,
  "ufmGatewayReloadingFinished" : _ufmGatewayReloadingFinished_vbinds,
  "ufmVcenterisDown" : _ufmVcenterisDown_vbinds,
  "ufmVcenterbadaccesscredentials" : _ufmVcenterbadaccesscredentials_vbinds,
  "ufmSwitchUpgradeError" : _ufmSwitchUpgradeError_vbinds,
  "ufmHostUpgradeFailed" : _ufmHostUpgradeFailed_vbinds,
  "ufmSwitchFWUpgradeStarted" : _ufmSwitchFWUpgradeStarted_vbinds,
  "ufmSwitchSWUpgradeStarted" : _ufmSwitchSWUpgradeStarted_vbinds,
  "ufmSwitchUpgradeFinished" : _ufmSwitchUpgradeFinished_vbinds,
  "ufmHostFWUpgradeStarted" : _ufmHostFWUpgradeStarted_vbinds,
  "ufmHostSWUpgradeStarted" : _ufmHostSWUpgradeStarted_vbinds,
  "ufmModulestatusNOTPRESENT" : _ufmModulestatusNOTPRESENT_vbinds,
  "ufmSwitchModuleRemoved" : _ufmSwitchModuleRemoved_vbinds,
  "ufmModuleTemperatureThresholdReached" : _ufmModuleTemperatureThresholdReached_vbinds,
  "ufmSwitchModuleAdded" : _ufmSwitchModuleAdded_vbinds,
  "ufmModulestatusFAULT" : _ufmModulestatusFAULT_vbinds,
  "ufmDeviceActionStarted" : _ufmDeviceActionStarted_vbinds,
  "ufmSiteActionStarted" : _ufmSiteActionStarted_vbinds,
  "ufmSiteActionFailed" : _ufmSiteActionFailed_vbinds,
  "ufmSwitchChipAdded" : _ufmSwitchChipAdded_vbinds,
  "ufmSwitchChipRemoved" : _ufmSwitchChipRemoved_vbinds,
  "ufmDevicePendingReboot" : _ufmDevicePendingReboot_vbinds,
  "ufmSystemInformationismissing" : _ufmSystemInformationismissing_vbinds,
  "ufmSwitchIdentityValidationFailed" : _ufmSwitchIdentityValidationFailed_vbinds,
  "ufmDeviceUpgradeFinished" : _ufmDeviceUpgradeFinished_vbinds,
  "ufmUFMBackUpStarted" : _ufmUFMBackUpStarted_vbinds,
  "ufmUFMBackUpFinished" : _ufmUFMBackUpFinished_vbinds,
  "ufmUFMBackUpFinishedWithError" : _ufmUFMBackUpFinishedWithError_vbinds,
  "ufmCoreDumpCreated" : _ufmCoreDumpCreated_vbinds,
  "ufmSMUP" : _ufmSMUP_vbinds,
  "ufmSMFailover" : _ufmSMFailover_vbinds,
  "ufmSMSystemLogMessage" : _ufmSMSystemLogMessage_vbinds,
  "ufmSMLIDChange" : _ufmSMLIDChange_vbinds,
  "ufmFabricHealthReportInfo" : _ufmFabricHealthReportInfo_vbinds,
  "ufmFabricHealthReportWarning" : _ufmFabricHealthReportWarning_vbinds,
  "ufmFabricHealthReportError" : _ufmFabricHealthReportError_vbinds,
  "ufmUFM_relatedprocessisdown" : _ufmUFM_relatedprocessisdown_vbinds,
  "ufmLogspurgefailure" : _ufmLogspurgefailure_vbinds,
  "ufmRestartofUFM_relatedprocesssucceeded" : _ufmRestartofUFM_relatedprocesssucceeded_vbinds,
  "ufmUFMisbeingstopped" : _ufmUFMisbeingstopped_vbinds,
  "ufmUFMisbeingrestarted" : _ufmUFMisbeingrestarted_vbinds,
  "ufmUFMfailoverisbeingattempted" : _ufmUFMfailoverisbeingattempted_vbinds,
  "ufmUFMcannotconnecttoDB" : _ufmUFMcannotconnecttoDB_vbinds,
  "ufmDiskutilizationthresholdreached" : _ufmDiskutilizationthresholdreached_vbinds,
  "ufmMemoryutilizationthresholdreached" : _ufmMemoryutilizationthresholdreached_vbinds,
  "ufmCPUutilizationthresholdreached" : _ufmCPUutilizationthresholdreached_vbinds,
  "ufmFabricinterfaceisdown" : _ufmFabricinterfaceisdown_vbinds,
  "ufmUFMstandbyserverproblem" : _ufmUFMstandbyserverproblem_vbinds,
  "ufmSMisdown" : _ufmSMisdown_vbinds,
  "ufmSMisnotresponding" : _ufmSMisnotresponding_vbinds,
  "ufmDRBDBadCondition" : _ufmDRBDBadCondition_vbinds,
  "ufmRemoteUFM_SMSync" : _ufmRemoteUFM_SMSync_vbinds,
  "ufmRemoteUFM_SMproblem" : _ufmRemoteUFM_SMproblem_vbinds,
  "ufmMHPurgeFailed" : _ufmMHPurgeFailed_vbinds,
  "ufmUFMHealthWatchdogInfo" : _ufmUFMHealthWatchdogInfo_vbinds,
  "ufmUFMHealthWatchdogCritical" : _ufmUFMHealthWatchdogCritical_vbinds,
  "ufmTimeDiffBetweenHAServers" : _ufmTimeDiffBetweenHAServers_vbinds,
  "ufmDRBDTCPConnectionPerformance" : _ufmDRBDTCPConnectionPerformance_vbinds,
  "ufmDailyReportCompletedsuccessfully" : _ufmDailyReportCompletedsuccessfully_vbinds,
  "ufmDailyReportCompletedwithError" : _ufmDailyReportCompletedwithError_vbinds,
  "ufmDailyReportFailed" : _ufmDailyReportFailed_vbinds,
  "ufmDailyReportMailSentsuccessfully" : _ufmDailyReportMailSentsuccessfully_vbinds,
  "ufmDailyReportMailSentFailed" : _ufmDailyReportMailSentFailed_vbinds,
  "ufmGeneralExternalEventNotification" : _ufmGeneralExternalEventNotification_vbinds,
  "ufmGeneralExternalEventNotice" : _ufmGeneralExternalEventNotice_vbinds,
  "ufmGeneralExternalEventAlert" : _ufmGeneralExternalEventAlert_vbinds,
  "ufmGeneralExternalEventError" : _ufmGeneralExternalEventError_vbinds,
  "ufmUserConnected" : _ufmUserConnected_vbinds,
  "ufmUserDisconnected" : _ufmUserDisconnected_vbinds,
  "ufmUFMServerFailover" : _ufmUFMServerFailover_vbinds,
  "ufmEventsSuppression" : _ufmEventsSuppression_vbinds,
  "ufmReportSucceeded" : _ufmReportSucceeded_vbinds,
  "ufmReportFailed" : _ufmReportFailed_vbinds,
  "ufmCorrectionAttemptsPaused" : _ufmCorrectionAttemptsPaused_vbinds,
  "ufmMonitoringHistoryEnabled" : _ufmMonitoringHistoryEnabled_vbinds,
  "ufmMonitoringHistoryDisabled" : _ufmMonitoringHistoryDisabled_vbinds,
  "ufmMonitoringHistoryBadConnection" : _ufmMonitoringHistoryBadConnection_vbinds,
  "ufmMonitoringHistoryConnectionEstablished" : _ufmMonitoringHistoryConnectionEstablished_vbinds,
  "ufmMonitoringHistoryInconsistentVersion" : _ufmMonitoringHistoryInconsistentVersion_vbinds,
  "ufmMonitoringHistoryFailedsavemetadata" : _ufmMonitoringHistoryFailedsavemetadata_vbinds,
  "ufmMonitoringHistoryFailedupdatemetadata" : _ufmMonitoringHistoryFailedupdatemetadata_vbinds,
  "ufmMonitoringHistoryFailedsavedata" : _ufmMonitoringHistoryFailedsavedata_vbinds,
  "ufmMonitoringHistoryFailedgetmetadata" : _ufmMonitoringHistoryFailedgetmetadata_vbinds,
  "ufmMonitoringHistoryFailedgetdata" : _ufmMonitoringHistoryFailedgetdata_vbinds,
  "ufmMonitoringHistoryFailedremovefile" : _ufmMonitoringHistoryFailedremovefile_vbinds,
  "ufmMonitoringHistoryversionnotmatchesUFMversion" : _ufmMonitoringHistoryversionnotmatchesUFMversion_vbinds,
  "ufmMonitoringHistoryPurgeDBOccurred" : _ufmMonitoringHistoryPurgeDBOccurred_vbinds,
  "ufmMonitoringHistoryMigrationisnotcompleted" : _ufmMonitoringHistoryMigrationisnotcompleted_vbinds,
  "ufmMonitoringHistorypartitionutilizationthresholdreached" : _ufmMonitoringHistorypartitionutilizationthresholdreached_vbinds,
  "ufmMonitoringHistorylocalreportfilesareabouttobecleaned" : _ufmMonitoringHistorylocalreportfilesareabouttobecleaned_vbinds,
  "ufmMonitoringHistoryoldestDBtableisabouttoberemoved" : _ufmMonitoringHistoryoldestDBtableisabouttoberemoved_vbinds,
  "ufmMonitoringHistorypartitionisnotmounted" : _ufmMonitoringHistorypartitionisnotmounted_vbinds,
  "ufmNon_optimalLinkSpeed" : _ufmNon_optimalLinkSpeed_vbinds,
  "ufmUnhealthyIBPort" : _ufmUnhealthyIBPort_vbinds,
  "ufmFabricCollectorConnected" : _ufmFabricCollectorConnected_vbinds,
  "ufmFabricCollectorDisconnected" : _ufmFabricCollectorDisconnected_vbinds,
  "ufmHighdataretransmissioncountonport" : _ufmHighdataretransmissioncountonport_vbinds,
  "ufmDropEvents" : _ufmDropEvents_vbinds,
  "ufmCRCAlignErrors" : _ufmCRCAlignErrors_vbinds,
  "ufmUndersizePkts" : _ufmUndersizePkts_vbinds,
  "ufmOversizePkts" : _ufmOversizePkts_vbinds,
  "ufmFragments" : _ufmFragments_vbinds,
  "ufmJabbers" : _ufmJabbers_vbinds,
  "ufmCollisions" : _ufmCollisions_vbinds,
  "ufmAlignmentErrors" : _ufmAlignmentErrors_vbinds,
  "ufmFCSErrors" : _ufmFCSErrors_vbinds,
  "ufmSingleCollisionFrames" : _ufmSingleCollisionFrames_vbinds,
  "ufmMultipleCollisionFrames" : _ufmMultipleCollisionFrames_vbinds,
  "ufmSQETestErrors" : _ufmSQETestErrors_vbinds,
  "ufmDeferredTransmissions" : _ufmDeferredTransmissions_vbinds,
  "ufmLateCollisions" : _ufmLateCollisions_vbinds,
  "ufmExcessiveCollisions" : _ufmExcessiveCollisions_vbinds,
  "ufmInternalMacTransmitErrors" : _ufmInternalMacTransmitErrors_vbinds,
  "ufmInternalMacReceiveErrors" : _ufmInternalMacReceiveErrors_vbinds,
  "ufmCarrierSenseErrors" : _ufmCarrierSenseErrors_vbinds,
  "ufmFrameTooLongs" : _ufmFrameTooLongs_vbinds,
  "ufmSymbolErrors" : _ufmSymbolErrors_vbinds,
  "ufmFabricConfigurationStarted" : _ufmFabricConfigurationStarted_vbinds,
  "ufmFabricConfigurationCompleted" : _ufmFabricConfigurationCompleted_vbinds,
  "ufmFabricConfigurationFailed" : _ufmFabricConfigurationFailed_vbinds,
  "ufmDeviceConfigurationFailure" : _ufmDeviceConfigurationFailure_vbinds,
  "ufmDeviceConfigurationTimeout" : _ufmDeviceConfigurationTimeout_vbinds,
  "ufmProvisioningValidationFailure" : _ufmProvisioningValidationFailure_vbinds,
  "ufmSwitchisDown" : _ufmSwitchisDown_vbinds,
  "ufmSwitchisUp" : _ufmSwitchisUp_vbinds,
  "ufmDirectorSwitchisDown" : _ufmDirectorSwitchisDown_vbinds,
  "ufmDirectorSwitchisUp" : _ufmDirectorSwitchisUp_vbinds,
  "ufmModuleTemperatureLowThresholdReached" : _ufmModuleTemperatureLowThresholdReached_vbinds,
  "ufmModuleTemperatureHighThresholdReached" : _ufmModuleTemperatureHighThresholdReached_vbinds,
  "ufmModuleHighVoltage" : _ufmModuleHighVoltage_vbinds,
  "ufmModuleHighCurrent" : _ufmModuleHighCurrent_vbinds
}