
const fs = require('fs');

const codes = {
    "Critical":"critical",
    "Emergency":"critical",
    "Alert":"critical",
    "Error":"critical", 
    "Unavail":"critical", 
    "High":"critical",
    "Up":"ok", 
    "Down":"critical",
    "Failed":"critical",
    "Expired":"critical",
    "Exceeded":"critical", 
    "Rejected":"critical",
    "Alarm":"critical",
    "Blocked":"critical",
    "Emerg":"critical",
    "Criti":"critical",
    "Err":"critical",
    "Fail":"critical",
    "Bad":"critical",
    "Info":"warning",
    "Warning":"warning",
    "On":"ok",
    "Off":"warning",
    "Start":"ok", 
    "Stop":"warning",
    "Enabled":"ok", 
    "Disabled":"warning",
    "Low":"warning",
    "Warn":"warning",
    "Change":"warning",
    "ChangeReason":"warning",
    "NotAvail":"critical",
    "Avail":"ok", 
    "Online":"ok", 
    "WarnClear":"ok", 
    "AlarmClear":"ok",
    "Clear":"ok",
}

let events = {};
let argv = process.argv.slice(1);

if (argv.length < 2) {
    console.log("Usage: node process.js <filename>");
    process.exit(1);
} else {
    try {
        const data = fs.readFileSync(argv[1], 'utf8');
        const objs = JSON.parse(data);
        objs.forEach(e => {
            processTrap(e.trap);
        });
        console.log(JSON.stringify(events,null,2));
    } catch (err) {
        console.log(`Error reading file from disk: ${err}`);
    }
}


function processTrap(name) {
    let check = name;
    let status = "critical";
    var keys = Object.keys(codes);
    for (let i=0; i<keys.length; i++) {
        e = keys[i];
        if (name.endsWith(e)) {
            l = (name.length-e.length);
            check = name.substring(0,l);
            status = codes[e];
            break;
        }
    };
    events[name] = {};
    events[name].name = check;
    events[name].status = status
//    console.log(`${name}: ${codes[e]}`)
}
